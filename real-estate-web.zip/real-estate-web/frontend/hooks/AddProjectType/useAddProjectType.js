import axios from "axios";
import { useMutation } from "react-query";

const AddSubmit = async (data) => {
  console.log(data)
   try {
     const response = await axios.post("http://localhost:3001/AddProject", data);
     return response;
   } catch (error) {
     console.log("Error submitting form:", error);
   }
 };

export const AddProjectType = () => {
    return useMutation(AddSubmit);
  };