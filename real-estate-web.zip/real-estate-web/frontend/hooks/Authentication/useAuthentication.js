import axios from "axios";
import { useMutation } from "react-query";
const submitForm = async (data) => {
  try {
    const response = await axios.post("http://localhost:3001/loginpage", data);
    return response;
  } catch (error) {
    console.log("Error submitting form:", error);
  }
};
export const useSubmitForm = () => {
  return useMutation(submitForm);
};





