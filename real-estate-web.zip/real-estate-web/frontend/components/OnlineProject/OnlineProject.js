import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import Button from "react-bootstrap/Button";
import projectimage from "../../assets/onlineproject/online-image.png";
import "./OnlineProject.css";
const OnlineProject = () => {
  return (
    <section id="onlineproject-bg-img">
      <Container>
        <Row>
          <Col sm={8} className="left-side">
            <h2 className="heading">Online Project Presentation</h2>
            <p className="info">
              Directly by Builder Team | Latest Offers | Live Flat Tour
            </p>
            <InputGroup>
              <Form.Control
                className="inputText" 
                placeholder="Search Project, locality or builder"
              />
              <Button className="scheduleButton">Schedule Presentation</Button>
            </InputGroup>
          </Col>
          <Col sm={4}>
            <div className="projectImage">
              <img
                src={projectimage}
                width="100%"
                height="auto"
                alt="projectimage"
              />
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default OnlineProject;
