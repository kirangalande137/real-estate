import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "./endfooter.css";
function footer() {
  return (
    <Container fluid>
      <Row className="downfoot ">
        <Col md={6}  className="leftside">
          <span>© 2023-2024 Basera Estate Consultants</span>
        </Col>
        <Col md={6}  className="rightside">
          <span className="downlink">
            <a href="#">Terms & Conditions </a>|
          </span>
          <span className="downlink">
            <a href="#">Privacy Policy</a>|
          </span>
          <span className="downlink">
            <a href="#">Disclaimer</a>
          </span>
        </Col>
      </Row>
      </Container>
  );
}

export default footer;
