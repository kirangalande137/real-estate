import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Card from "react-bootstrap/Card";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import FavoriteIcon from "@mui/icons-material/Favorite";
import CommentIcon from "@mui/icons-material/Comment";
import ShareIcon from "@mui/icons-material/Share";
import SearchIcon from "@mui/icons-material/Search";
import ArrowRightIcon from "@mui/icons-material/ArrowRight";
import { Outlet, Link } from "react-router-dom";
import img1 from "../../assets/Blog/b-1 (1).jpg";
import img2 from "../../assets/Blog/b-2.jpg";
import img3 from "../../assets/Blog/b-3.jpg";
import client1 from "../../assets/Blog/ts-2.jpg";
import "./BlogDetails.css";

const categorydata = [
  {
    id: 0,
    name: "House",
  },
  {
    id: 1,
    name: "Garages",
  },
  {
    id: 2,
    name: "Real Estate",
  },
  {
    id: 3,
    name: "Real Home",
  },
  {
    id: 4,
    name: "Bath",
  },
  {
    id: 5,
    name: "Beds",
  },
];
const populartagsdata = [
  {
    id: 0,
    name: "Houses",
  },
  {
    id: 1,
    name: "Real Home",
  },
  {
    id: 2,
    name: "Bath",
  },
  {
    id: 3,
    name: "Beds",
  },
  {
    id: 4,
    name: "Garages",
  },
  {
    id: 5,
    name: "Real Estates",
  },
  {
    id: 6,
    name: "Garages",
  },
  {
    id: 7,
    name: "Properties",
  },
  {
    id: 8,
    name: "Location",
  },
  {
    id: 9,
    name: "Price",
  },
];

const recentpostdata = [
  {
    id: 0,
    img: img1,
    name: "Real State",
    date: "May 10, 2020",
  },
  {
    id: 1,
    img: img2,
    name: "Real State",
    date: "May 10, 2020",
  },
  {
    id: 2,
    img: img3,
    name: "Real State",
    date: "May 10, 2020",
  },
];

const commentsdata = [
  {
    id: 0,
    clientimg: client1,
    name: "Mario Smith",
    date: "Jun 23, 2020",
    comment:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras aliquam, quam congue dictum luctus, lacus magna congue ante, in finibus dui sapien eu dolor. Integer tincidunt suscipit erat, nec laoreet ipsum vestibulum sed.",
  },
  {
    id: 1,
    clientimg: client1,
    name: "Mario Smith",
    date: "Jun 23, 2020",
    comment:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras aliquam, quam congue dictum luctus, lacus magna congue ante, in finibus dui sapien eu dolor. Integer tincidunt suscipit erat, nec laoreet ipsum vestibulum sed.",
  },
  {
    id: 2,
    clientimg: client1,
    name: "Mario Smith",
    date: "Jun 23, 2020",
    comment:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras aliquam, quam congue dictum luctus, lacus magna congue ante, in finibus dui sapien eu dolor. Integer tincidunt suscipit erat, nec laoreet ipsum vestibulum sed.",
  },
];

const BlogDetails = () => {
  return (
    <>
      <Container fluid className="BlogDetails-Container1">
        <h1 className="BlogDetails-heading">
          Blog Details
          <h2 className="BlogDetails-heading-caption">
            <Link to="/">Home</Link> / Blog Details
          </h2>
        </h1>
      </Container>
      <Container>
        <Row className="BlogDetails-row">
          <Col md={9}>
            <div className="BlogDetails-news">
              <Card className="BlogDetails-card">
                <Card.Img variant="top" src={img1} />
                <Card.Body>
                  <Container>
                    <Card.Title>
                      <a href="#" className="BlogDetails-news-title">
                        Real Estate News
                      </a>
                    </Card.Title>
                    <Card.Text>
                      <div>
                        <div className="BlogDetails-news-date">
                          <span>April 11, 2020 / </span>
                          <ul>
                            <li>
                              <div className="BlogDetails-news-date-icon">
                                <FavoriteIcon sx={{ fontSize: 14 }} />
                              </div>
                              375
                            </li>
                            <li>
                              <div className="BlogDetails-news-date-icon">
                                <CommentIcon sx={{ fontSize: 14 }} />
                              </div>
                              34
                            </li>
                            <li>
                              <div className="BlogDetails-news-date-icon">
                                <ShareIcon sx={{ fontSize: 14 }} />
                              </div>
                              122
                            </li>
                          </ul>
                        </div>
                        <div className="BlogDetails-news-text">
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing
                            elit. Autem, ea? Vitae pariatur ab amet iusto
                            tempore neque a, deserunt eaque recusandae obcaecati
                            eos atque delectus. Lorem ipsum dolor sit amet,
                            consectetur adipisicing elit. Eligendi labore vel
                            enim repellendus excepturi autem. Eligendi cum
                            laboriosam exercitationem illum repudiandae quasi
                            sint dicta consectetur porro fuga ea, perspiciatis
                            aut!
                          </p>
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing
                            elit. Autem, ea? Vitae pariatur ab amet iusto
                            tempore neque a, deserunt eaque recusandae obcaecati
                            eos atque delectus. Lorem ipsum dolor sit amet,
                            consectetur adipisicing elit. Eligendi labore vel
                            enim repellendus excepturi autem. Eligendi cum
                            laboriosam exercitationem illum repudiandae quasi
                            sint dicta consectetur porro fuga ea, perspiciatis
                            aut!
                          </p>
                        </div>
                      </div>
                    </Card.Text>
                  </Container>
                </Card.Body>
              </Card>
              <div>
                <div>
                  <h5 className="BlogDetails-headings">5 Comments</h5>
                </div>
                {commentsdata.map((data) => (
                  <div className="BlogDetails-comments" key={data.id}>
                    <div className="BlogDetails-comments-img">
                      <img src={data.clientimg} />
                    </div>
                    <div>
                      <h6>{data.name}</h6>
                      <p>{data.date}</p>
                      <p>{data.comment}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h5 className="BlogDetails-headings">Leave a Comment</h5>
              <Form className="BlogDetails-from">
                <Form.Group className="mb-3">
                  <Form.Control
                    type="text"
                    placeholder="First Name"
                    className="BlogDetails-from-info"
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Control
                    type="text"
                    placeholder="Last Name"
                    className="BlogDetails-from-info"
                  />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                  <Form.Control
                    type="email"
                    placeholder="Email"
                    className="BlogDetails-from-info"
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Control
                    placeholder="Message"
                    as="textarea"
                    style={{ height: "100px" }}
                    className="BlogDetails-from-info"
                  />{" "}
                </Form.Group>
                <Button type="submit">
                  Submit Comment
                </Button>
              </Form>
            </div>
          </Col>
          <Col md={3}>
            <div className="BlogDetails-right">
              <div>
                <h5 className="BlogDetails-headings">Search</h5>
              </div>
              <div className="BlogDetails-search">
                <Form className="d-flex">
                  <Form.Control
                    type="search"
                    placeholder="Search for..."
                    aria-label="Search"
                  />
                  <Button>
                    <SearchIcon />
                  </Button>{" "}
                </Form>
              </div>
              <div>
                <h5 className="BlogDetails-headings">Category</h5>
              </div>
              <div className="BlogDetails-category">
                <ul>
                  {categorydata.map((data) => (
                    <a href="#">
                      <li key={data.id}>
                        <ArrowRightIcon />
                        {data.name}
                      </li>
                    </a>
                  ))}
                </ul>
              </div>
              <div>
                <h5 className="BlogDetails-headings">Popular Tags</h5>
              </div>
              <div className="BlogDetails-populartags">
                {populartagsdata.map((data) => (
                  <Button key={data.id}>{data.name}</Button>
                ))}
              </div>
              <div>
                <h5 className="BlogDetails-headings">Recent Posts</h5>
              </div>
              {recentpostdata.map((data) => (
                <div className="BlogDetails-recentposts" key={data.id}>
                  <div className="BlogDetails-recentposts-img">
                    <img src={data.img} />
                  </div>
                  <div className="BlogDetails-recentposts-date">
                    <a href="#">
                      <h6>{data.name}</h6>
                    </a>
                    <p>{data.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default BlogDetails;
