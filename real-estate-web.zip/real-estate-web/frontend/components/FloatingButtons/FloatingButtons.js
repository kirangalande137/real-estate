import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "./FloatingButtons.css";
import WhatsAppIcon from "@mui/icons-material/WhatsApp";
import Button from "react-bootstrap/Button";

import FacebookIcon from "@mui/icons-material/Facebook";
import TwitterIcon from "@mui/icons-material/Twitter";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import InstagramIcon from "@mui/icons-material/Instagram";
import YouTubeIcon from "@mui/icons-material/YouTube";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";

const data = [
  {
    id: 1,
    icon: <FacebookIcon fontSize="small" />,
  },
  {
    id: 2,
    icon: <TwitterIcon fontSize="small" />,
  },
  {
    id: 3,
    icon: <LinkedInIcon fontSize="small" />,
  },
  {
    id: 4,
    icon: <InstagramIcon fontSize="small" />,
  },
  {
    id: 5,
    icon: <YouTubeIcon fontSize="small" />,
  },
  {
    id: 6,
    icon: <WhatsAppIcon fontSize="small" />,
  },
];

const FloatingButtons = (props) => {
  return (
    <div>
      <div>
        {/* props.IconButtons=FloatingButtons?<div className="FloatingButtons-right-whatsapp">
          <WhatsAppIcon fontSize="large"/>
        </div>:<div className="FloatingButtons-right-EnqurieButton">
          <EnqurieButton />
        </div>; */}
        {props.buttontype1 === "enqurie" && props.buttontype2 === "whatsapp" ? (
          <>
            <div className="FloatingButtons-right-EnqurieButton">
              <Button variant="warning">{props.name}</Button>
            </div>
            {/* <div className="FloatingButtons-right-whatsapp">
              <WhatsAppIcon fontSize="large" />
            </div> */}                                                   { /* whatsapp floting button  */}
          </>
        ) : null}
      </div>

      <div className="FloatingButtons-left">
        <div>
          {data.map((user) => (
            <div className="FloatingButtons-left-padding" key={user.id}>{user.icon}</div>
          ))}
        </div>
      </div>

      <div className="FloatingButtons-bottom">
        <Container>
          <Row>
            <Col>
              <WhatsAppIcon fontSize="large" />
            </Col>
            <Col>
              <LocalPhoneIcon fontSize="large" />
            </Col>
          </Row>
        </Container>
      </div>
    </div>
  );
};

export default FloatingButtons;
