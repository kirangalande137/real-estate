import React, { useState } from "react";
import { Formik } from "formik";
import logo from "../../assets/logo/logo.png";
import "./Login.css";
import { useNavigate } from "react-router-dom";
import { useSubmitForm } from "../../hooks/Authentication/useAuthentication";
import Button from "@mui/material/Button";
import Alert from "@mui/material/Alert";
const Login = () => {
  const navigate = useNavigate();
  const handleChange = (event) => {};
  const { mutate, isLoading } = useSubmitForm();

  const [userMessage, setUserMessage] = React.useState("");

  console.log(userMessage);

  const SubmitOn = (values) => {
    // submitForm(values);
    mutate(values, {
      onSuccess: (data) => {
        setUserMessage(data);
        if (data.data === "Login successful") {
          setUserMessage(data.data);
          navigate("/");
        } else {
          setUserMessage(data.data);
          navigate("/loginpage");
        }
      },
    });
  };

  return (
    <section className="loginform-img">
      <div className="loginform-section">
        <Formik
          initialValues={{ email: "", password: "" }}
          validate={(values) => {
            const errors = {};
            if (!values.email) {
              errors.email = "Required";
            } else if (
              !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
            ) {
              errors.email = "Invalid email address";
            }
            return errors;
          }}
          onSubmit={SubmitOn}
        >
          {({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
            isSubmitting,
            /* and other goodies */
          }) => (
            <form onSubmit={handleSubmit} className="loginform">
              <h1 className="loginform-logo">
                <img src={logo} />
              </h1>
              <h6>
                {userMessage !== "" ? (
                  <Alert severity="error">{userMessage}</Alert>
                ) : null}
              </h6>
              <label htmlFor="email">Email</label>
              <br></br>
              <input
                type="email"
                name="email"
                placeholder="Email"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.email}
                className="loginforminfo"
              />
              <br></br>
              {errors.email && touched.email && errors.email}
              <br></br>
              <label htmlFor="password">Password</label>
              <br></br>
              <input
                type="password"
                name="password"
                placeholder="Password"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.password}
                className="loginforminfo"
              />

              {errors.password && touched.password && errors.password}
              <div className="loginformbuttoncenter">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="loginformbutton"
                  loading={isLoading}
                >
                  Log In
                </Button>
              </div>
            </form>
          )}
        </Formik>
      </div>
    </section>
  );
};

export default Login;
