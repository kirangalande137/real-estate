import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "./Aboutus.css";
import aboutimg from "../../assets/AboutUs/about.jpg";
import ouraim from "../../assets/AboutUs/our-aim.jpg";
import ourvalue from "../../assets/AboutUs/our-value.jpg";
import ourprinciple from "../../assets/AboutUs/our-vision.jpg";
const Aboutus = () => {
  return (
    <section className="aboutus-section">
      <div className="aboutus-heading">
        <h1>ABOUT US</h1>
      </div>
      <Container>
        <div className="aboutus-info">
          <Row>
            <Col xs={12} md={5}>
              <div>
              <img src={aboutimg} className="aboutus-img" />
              </div>
            </Col>
            <Col xs={12} md={7}>
              <p>
                Welcome to Basera Estate Consultants, where excellence meets
                innovation in the dynamic landscape of Mumbai's real estate
                market. As a leading force in the industry, Basera Estate
                Consultants LLP takes pride in achieving the highest standards
                of performance, pioneering initiatives that have become
                benchmarks for others to emulate.
              </p>
              <p>
                Our journey is marked by unwavering expertise, a steadfast
                commitment to our craft, unmatched professionalism, and a
                reputation for dependability, collectively positioning us as the
                most influential real estate agent in Mumbai. We are proudly
                registered with Maharera, attesting to our certification as
                trusted real estate professionals.
              </p>
              <p>
                At the core of our success is a distinctive methodology,
                characterized by a professional demeanor, cutting-edge marketing
                tools, and an unparalleled team of qualified agents.
              </p>
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={12}>
              <p>
                We stand out in the industry by delivering exceptional service
                to our clients, setting new norms, and consistently raising the
                bar for excellence.
              </p>
              <p>
                Welcome to Basera Estate Consultants, where excellence meets
                innovation in the dynamic landscape of Mumbai's real estate
                market. As a leading force in the industry, Basera Estate
                Consultants LLP takes pride in achieving the highest standards
                of performance, pioneering initiatives that have become
                benchmarks for others to emulate.
              </p>
              <p>
                Our journey is marked by unwavering expertise, a steadfast
                commitment to our craft, unmatched professionalism, and a
                reputation for dependability, collectively positioning us as the
                most influential real estate agent in Mumbai. We are proudly
                registered with Maharera, attesting to our certification as
                trusted real estate professionals.
              </p>
              <p>
                At the core of our success is a distinctive methodology,
                characterized by a professional demeanor, cutting-edge marketing
                tools, and an unparalleled team of qualified agents. We stand
                out in the industry by delivering exceptional service to our
                clients, setting new norms, and consistently raising the bar for
                excellence.
              </p>
            </Col>
            {/* <Col xs={12} md={5}>
            <img src={aboutimg} className="aboutus-img" />
          </Col> */}
          </Row>
        </div>
        <div className="aboutus-info">
          <Row>
            <h3 className="aboutus-ouraim-heading">OUR AIM</h3>
            <Col xs={12} md={5}>
              {/* <p className="aboutus-img-heading">About Us Basera</p> */}
              <img src={ouraim} className="aboutus-img" />
            </Col>
            <Col xs={12} md={7}>
              <p>
                At Basera Estate Consultants, our aim transcends the ordinary;
                we aspire to leave our customers not just satisfied but
                thoroughly delighted with the pinnacle of services in our areas
                of profound expertise. Our commitment to excellence is woven
                into the fabric of our organization, guiding us towards a future
                where every real estate journey is a testament to unparalleled
                satisfaction. Our primary aim is to be the unrivaled experts in
                the real estate domain. We strive to surpass conventional norms,
                offering a level of expertise that goes beyond expectations. By
                constantly honing our skills and staying abreast of industry
                trends, we aim to be the go-to source for comprehensive real
                estate solutions. Recognizing that each client is unique, our
                aim is to tailor our services to match individual needs and
                aspirations. We take pride in our ability to provide
                personalized solutions, ensuring that every interaction with
                Basera Estate Consultants is an experience tailored for complete
                satisfaction.
              </p>
            </Col>
          </Row>
          <Row>
            <Col xs={12} md={12}>
              <p>
                Our aim is not just to meet industry standards but to set them.
                By fostering a culture of innovation, we aspire to lead the way
                in redefining what's possible in the real estate realm.
              </p>
              <p>
                Through forward-thinking strategies and groundbreaking
                approaches, we aim to consistently exceed expectations and set
                new benchmarks. Our aim at Basera Estate Consultants is to
                elevate satisfaction to a level beyond imagination. We don't
                just aim to meet expectations; we strive to surpass them,
                creating an unparalleled real estate experience that leaves our
                clients not just satisfied but genuinely fulfilled. Join us as
                we redefine the benchmarks of satisfaction in the world of real
                estate.
              </p>
            </Col>
          </Row>
        </div>
        <div className="aboutus-info">
          <Row>
            <h3 className="aboutus-ouraim-heading">OUR VALUES</h3>
            <Col xs={12} md={8}>
              <p>
                At Basera Estate Consultants, our values are more than just
                words on paper; they are the guiding principles that define who
                we are and shape our actions. Our commitment to becoming the
                leading real estate company in Mumbai by providing world-class
                real estate services is anchored in these core values.
                Collaboration and teamwork are fundamental to our success. We
                recognize that our diverse and highly skilled team is our
                greatest asset. By working together cohesively, we leverage each
                other's strengths to deliver exceptional results for our
                clients. Teamwork fosters creativity, efficiency, and a positive
                work environment. our values at Basera Estate Consultants are
                the compass that guides us towards our goal of becoming the
                leading real estate company in Mumbai. These values are not just
                words but principles that inform every decision, action, and
                interaction within our organization. Join us in experiencing the
                Basera Estate Consultants difference, where our values are the
                bedrock of our commitment to excellence in real estate services.
              </p>
            </Col>
            <Col xs={12} md={4}>
              <img src={ourvalue} className="aboutus-img" />
            </Col>
          </Row>
        </div>
        <div className="aboutus-info">
          <Row>
            <h3 className="aboutus-ouraim-heading">OUR AIM</h3>
            <Col xs={12} md={5}>
              <img src={ourprinciple} className="aboutus-img" />
            </Col>
            <Col xs={12} md={7}>
              <p>
                At Basera Estate Consultants, our aim transcends the ordinary;
                we aspire to leave our customers not just satisfied but
                thoroughly delighted with the pinnacle of services in our areas
                of profound expertise. Our commitment to excellence is woven
                into the fabric of our organization, guiding us towards a future
                where every real estate journey is a testament to unparalleled
                satisfaction. Our primary aim is to be the unrivaled experts in
                the real estate domain. We strive to surpass conventional norms,
                offering a level of expertise that goes beyond expectations. By
                constantly honing our skills and staying abreast of industry
                trends, we aim to be the go-to source for comprehensive real
                estate solutions. Recognizing that each client is unique, our
                aim is to tailor our services to match individual needs and
                aspirations. We take pride in our ability to provide
                personalized solutions, ensuring that every interaction with
                Basera Estate Consultants is an experience tailored for complete
                satisfaction.
              </p>
            </Col>
          </Row>
        </div>
      </Container>
    </section>
  );
};

export default Aboutus;
