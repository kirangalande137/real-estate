import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import HomeIcon from "@mui/icons-material/Home";
import MailOutlineIcon from "@mui/icons-material/MailOutline";
import PhoneAndroidIcon from "@mui/icons-material/PhoneAndroid";
import DriveFileRenameOutlineIcon from "@mui/icons-material/DriveFileRenameOutline";
import PhoneIcon from "@mui/icons-material/Phone";

import "./footer.css";
import { WidthFull } from "@mui/icons-material";
import { Outlet, Link } from "react-router-dom";
// import { red } from "@mui/material/colors";

const data = [
  { id: 1, name: "Home" },
  { id: 2, name: "About us" },
  { id: 3, name: "Services" },
  { id: 4, name: "Project" },
  { id: 5, name: "Properties" },
  { id: 6, name: "Blog" },
  { id: 7, name: "Career" },
  { id: 8, name: "Contact us" },
  { id: 9, name:  "Login" ,link: <Link to="/loginpage"></Link> },
];

const footer = () => {
  return (
    <Container fluid>
      <Row className="foot">
        <Col md={3}>
          <h4>CONTACT US</h4>
          <div className="leftleft">
            <span>
              <h6 className="icon">
                <HomeIcon /> Address :{" "}
              </h6>
              <p>
                Basera Estate Consultants
                <br /> Shop No 5, Roop Apartment,
                <br /> Off S V Road, Below Ruby Hospital,
                <br /> Jogeshwari West, Mumbai - 400102.
              </p>
              <h6 className="icon">
                <MailOutlineIcon /> EMAIL :{" "}
              </h6>
              <p>info@baseraestate.co.in</p>
              <h6 className="icon">
                <PhoneAndroidIcon /> +91 99999 99999{" "}
              </h6>
            </span>
          </div>
        </Col>
        <Col md={3}>
          <h4>QUICK LINKS</h4>
          <div className="left">

            {data.map((user) => (
              <div key={user.id}>
                <Link href={user.link} className="alink">
                  {user.name}
                </Link>
              </div>
            ))}
            
          </div>
        </Col>
        <Col md={3}>
          <h4>ABHOUT US</h4>
          <div className="right">
            <p>
              Welcome to Basera Estate Consultants, where excellence meets
              innovation in the dynamic landscape of Mumbai real estate market.
              As a leading force in the industry, Basera Estate Consultants LLP
              takes pride in achieving the highest standards of performance,
              pioneering initiatives that have become benchmarks for others to
              emulate.....
              <br />
              <a href="#" className="viewm">
                view more
              </a>
            </p>
          </div>
        </Col>
        <Col md={3}>
          <h4>QUICK ENQUICK</h4>
          <div>
            <form>
              <div className="rightright">
                
                <div className="finfo">                 
                  <input type="text" placeholder="Enter name" style={{ width: '-webkit-fill-available', width: '100%' }}/>
                </div>

                <div className="finfo">               
                  <input type="number" placeholder="+91 99999 99999" style={{ width: '-webkit-fill-available', width: '100%' }}/>
                </div>

                <div className="finfo">
                  <input type="text" placeholder="Enter email" style={{ width: '-webkit-fill-available', width: '100%' }}/>
                </div>
                
                <div className="finfo">
                <p>18 + 17</p>
                  <input type="text" style={{ width: '-webkit-fill-available', width: '100%' }}/><br/>
                <p>Please verify.</p>
                </div>
                

                <div className="fbut">
                  <button type="submit" className="but1">Send</button> &nbsp;
                  <button type="submit" className="but2">Reset</button>
                </div>
              </div>
            </form>
          </div>
        </Col>
      </Row>
    </Container>
  );
};
export default footer;
