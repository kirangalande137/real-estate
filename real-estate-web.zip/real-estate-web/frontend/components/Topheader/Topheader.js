import { Box } from "@mui/material";
import React from "react";
import SmartphoneIcon from "@mui/icons-material/Smartphone";
import FacebookOutlinedIcon from "@mui/icons-material/FacebookOutlined";
import InstagramIcon from "@mui/icons-material/Instagram";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import "./Topheader.css";

const Topheader = () => {
  return (
    <Box className="top-header-wrapper">
      <Box className="d-flex align-item-center justify-content-between">
        <span className="d-flex align-item-center justify-content-between mx-2">
          <SmartphoneIcon />
          <h3>+91 99999 99999</h3>
        </span>
        <span className="d-flex align-item-center justify-content-between mx-2">
          <EmailOutlinedIcon />
          <h3>rabs@gmail.com</h3>
        </span>
      </Box>
      <Box>
        <FacebookOutlinedIcon />
        <InstagramIcon />
      </Box>
    </Box>
  );
};

export default Topheader;
