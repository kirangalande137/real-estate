import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Card from "react-bootstrap/Card";
import FavoriteIcon from "@mui/icons-material/Favorite";
import CommentIcon from "@mui/icons-material/Comment";
import ShareIcon from "@mui/icons-material/Share";
import projectimg1 from "../../assets/Blog/b-1.jpg";
import projectimg2 from "../../assets/Blog/b-2.jpg";
import projectimg3 from "../../assets/Blog/b-3.jpg";
// import projectimg4 from "../../assets/Blog/b-4.jpg";
// import projectimg5 from "../../assets/Blog/b-5.jpg";
import clientimg1 from "../../assets/Blog/ts-1.jpg";
import clientimg2 from "../../assets/Blog/ts-2.jpg";
import clientimg3 from "../../assets/Blog/ts-3.jpg";
import clientimg4 from "../../assets/Blog/ts-4.jpg";
import clientimg5 from "../../assets/Blog/ts-5.jpg";
import "./Blog.css";
import BlogDetails from "../../components/BlogDetails/BlogDetails";
import { Outlet, Link } from "react-router-dom";

const data = [
  {
    id: 0,
    blogimg: projectimg1,
    title: "Real Estate News",
    date: "April 11,2020",
    like: "306",
    comment: "24",
    share: "122",
    text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ipsum dolor sit amet, consectetur.",
    clientname: "By, Lisa Jhonson",
    clientimg: clientimg1,
  },
  {
    id: 1,
    blogimg: projectimg2,
    title: "Real Estate News",
    date: "April 11,2020",
    like: "306",
    comment: "24",
    share: "122",
    text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ipsum dolor sit amet, consectetur.",
    clientname: "By, Lisa Jhonson",
    clientimg: clientimg2,
  },
  {
    id: 2,
    blogimg: projectimg3,
    title: "Real Estate News",
    date: "April 11,2020",
    like: "306",
    comment: "24",
    share: "122",
    text: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ipsum dolor sit amet, consectetur.",
    clientname: "By, Lisa Jhonson",
    clientimg: clientimg3,
  },
];

const Blog = () => {
  return (
    <section className="Blog">
      <div>
        <Container>
          <Row className="Blog-row">
            {" "}
            <h1 className="Blog-heading">BLOG</h1>
            {data.map((blog) => (
              <Col xs={12} md={4} style={{ width: "23rem" }} key={blog.id}>
                <div className="Blog-news">
                  <Card>
                  <Link to="/blogdetails"><Card.Img variant="top" src={blog.blogimg} /></Link>
                    <Card.Body>
                      <Container>
                        <Card.Title>
                          <Link to="#" className="Blog-news-title">
                            {blog.title}
                          </Link>
                        </Card.Title>
                        <Card.Text>
                          <div>
                            <div className="Blog-news-date">
                              <span>{blog.date} / </span>
                              <ul>
                                <li>
                                  <div className="Blog-news-date-icon">
                                    <FavoriteIcon sx={{ fontSize: 14 }} />
                                  </div>
                                  {blog.like}
                                </li>
                                <li>
                                  <div className="Blog-news-date-icon">
                                    <CommentIcon sx={{ fontSize: 14 }} />
                                  </div>
                                  {blog.comment}
                                </li>
                                <li>
                                  <div className="Blog-news-date-icon">
                                    <ShareIcon sx={{ fontSize: 14 }} />
                                  </div>
                                  {blog.share}
                                </li>
                              </ul>
                            </div>
                            <div className="Blog-news-text">
                              <p>
                                {blog.text}
                              </p>
                            </div>
                            <div className="Blog-news-footer">
                              <a href="#">Read More...</a>
                              <div className="Blog-news-footer-client">
                                <p>{blog.clientname}</p>
                                <img src={blog.clientimg} />
                              </div>
                            </div>
                          </div>
                        </Card.Text>
                      </Container>
                    </Card.Body>
                  </Card>
                </div>
              </Col>
            ))}
            {/* <Col xs={12} md={4} style={{ width: "21rem" }}>
              <div className="Blog-news">
                <Card>
                  <Card.Img variant="top" src={projectimg1} />
                  <Card.Body>
                    <Card.Title>Card Title</Card.Title>
                    <Card.Text>
                      Some quick example text to build on the card title and
                      make up the bulk of the card's content.
                    </Card.Text>{" "}
                  </Card.Body>
                </Card>
              </div>
            </Col>
            <Col xs={12} md={4} style={{ width: "21rem" }}>
              <div className="Blog-news">
                <Card>
                  <Card.Img variant="top" src={projectimg1} />
                  <Card.Body>
                    <Card.Title>Card Title</Card.Title>
                    <Card.Text>
                      Some quick example text to build on the card title and
                      make up the bulk of the card's content.
                    </Card.Text>{" "}
                  </Card.Body>
                </Card>
              </div>
            </Col>
            <Col xs={12} md={4} style={{ width: "21rem" }}>
              <div className="Blog-news">
                <Card>
                  <Card.Img variant="top" src={projectimg1} />
                  <Card.Body>
                    <Card.Title>Card Title</Card.Title>
                    <Card.Text>
                      Some quick example text to build on the card title and
                      make up the bulk of the card's content.
                    </Card.Text>{" "}
                  </Card.Body>
                </Card>
              </div>
            </Col>
            <Col xs={12} md={4} style={{ width: "21rem" }}>
              <div className="Blog-news">
                <Card>
                  <Card.Img variant="top" src={projectimg1} />
                  <Card.Body>
                    <Card.Title>Card Title</Card.Title>
                    <Card.Text>
                      Some quick example text to build on the card title and
                      make up the bulk of the card's content.
                    </Card.Text>{" "}
                  </Card.Body>
                </Card>
              </div>
            </Col> */}
          </Row>
        </Container>
      </div>
    </section>
  );
};

export default Blog;
