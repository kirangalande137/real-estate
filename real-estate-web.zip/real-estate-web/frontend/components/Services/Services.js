import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "./Services.css";
import HandshakeIcon from "@mui/icons-material/Handshake";
import HomeRepairServiceIcon from "@mui/icons-material/HomeRepairService";
import ApartmentIcon from "@mui/icons-material/Apartment";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
import { Outlet, Link } from "react-router-dom";

const servicesdataleft = [
  {
    id: 0,
    icon: <HandshakeIcon sx={{ fontSize: 70 }} />,
    name: "Real Estate Consulting:",
    info: "Our Real Estate Consulting services are designed to be your guiding light in the complex world of real estate. Whether you're a first-time homebuyer or a seasoned investor, our expert consultants provide insights, market trends, and personalized advice to help you make informed decisions. Your real estate aspirations are met with tailored solutions and strategic guidance.",
  },
  {
    id: 1,
    icon: <ApartmentIcon sx={{ fontSize: 70 }} />,
    name: "Pre Sales Services:",
    info: "The journey begins before the sale, and our Pre Sales Services are designed to make this initial phase as smooth as possible. From property valuation and market analysis to staging and marketing strategies, we ensure that your property is positioned for success in the market. Obitel Prime Realtors takes care of the details, allowing you to embark on your real estate journey with confidence.",
  },
  {
    id: 2,
    icon: <AccountBalanceIcon sx={{ fontSize: 70 }} />,
    name: "Banking Assistance:",
    info: "Navigating the financial aspects of real estate can be intricate, and our Banking Assistance services are here to simplify the process. Obitel Prime Realtors collaborates with leading banks to offer you assistance in securing loans, mortgage advice, and understanding financial implications. Your financial journey becomes an integral part of your overall real estate experience.",
  },
];

const servicesdataright = [
  {
    id: 0,
    icon: <HomeRepairServiceIcon sx={{ fontSize: 70 }} />,
    name: "NRI Consulting Services:",
    info: "For our Non-Resident Indian (NRI) clients, our specialized NRI Consulting Services bridge the gap between distances. We understand the unique challenges and opportunities that come with overseas investments. Obitel Prime Realtors ensures that your real estate transactions in India are smooth, transparent, and aligned with your goals, no matter where in the world you are.",
  },
  {
    id: 1,
    icon: <ApartmentIcon sx={{ fontSize: 70 }} />,
    name: "Post Sales Services:",
    info: "Our commitment to your satisfaction extends beyond the sale with our Post Sales Services. Whether it's assistance with documentation, property management, or transitioning into your new home, Obitel Prime Realtors is your partner in ensuring a seamless post-sales experience. We believe in building lasting relationships, and our post-sales support reflects this commitment.",
  },
  {
    id: 3,
    icon: <ApartmentIcon sx={{ fontSize: 70 }} />,
    name: "Legal Assistance:",
    info: "Legal intricacies should never be a barrier to your real estate aspirations. Obitel Prime Realtors provides Legal Assistance services to ensure that your transactions are compliant, transparent, and secure. Our team of legal experts guides you through the legal landscape, offering advice, facilitating documentation, and safeguarding your interests.",
  },
];

const Services = () => {
  return (
    <section className="services-section">
      <div className="services-heading">
        <h1>OUR SERVICES</h1>
        <h2 className="services-link"><Link to="/">Home</Link> / Blog Details</h2>
      </div>
      <Container>
        <Row className="services-info">
          <p>
            Welcome to the Service Hub of Basera Estate Consultants, where we go
            beyond transactions to provide a comprehensive suite of services
            that redefine your real estate journey. Our commitment to excellence
            extends across various facets, ensuring that your experience with us
            is seamless, informed, and rewarding. Here's how we enhance your
            real estate adventure:
          </p>
          <Col xs={12} md={6}>
            {servicesdataleft.map((data) => (
              <div className="serivces-box" key={data.id}>
                <div className="serivces-img">{data.icon}</div>
                <div>
                  <h1>{data.name}</h1>
                  <p>{data.info}</p>
                </div>
              </div>
            ))}
          </Col>
          <Col xs={12} md={6}>
            {servicesdataright.map((data) => (
              <div className="serivces-box" key={data.id}>
                <div className="serivces-img">{data.icon}</div>
                <div>
                  <h1>{data.name}</h1>
                  <p>{data.info}</p>
                </div>
              </div>
            ))}
          </Col>
          <p>
            At Basera Estate Consultants, our services are not just about
            transactions; they're about building relationships and ensuring that
            every step of your real estate journey is met with expertise,
            transparency, and unwavering support. Whether you're buying,
            selling, or investing, we invite you to explore our comprehensive
            services and experience a new standard of excellence in real estate.
            Your journey with Basera Estate Consultants begins with exceptional
            service.
          </p>
        </Row>
      </Container>
    </section>
  );
};

export default Services;
