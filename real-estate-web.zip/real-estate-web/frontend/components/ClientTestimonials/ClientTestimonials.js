import React from "react";
import Carousel from 'react-bootstrap/Carousel';
import user from '../../assets/ClientTestimonials/user1.png'
import "./ClientTestimonials.css";
const ClientTestimonials = () => {
  return (
    <section className="ClientTestimonials">
      <Carousel data-bs-theme="dark">
      <Carousel.Item>
          <h2 className="ClientTestimonials-head">CLIENT TESTIMONIALS</h2>
          <div className="ClientTestimonials-padding">
          <img src={user} alt="user"/>
          <p className="ClientTestimonials-info">" Best Real estate company in Mumbai.. Sales staff is very cooperative and highly professional.. 
          Thanxx Basera Estate Consultants for my Dream Home  "</p><br/>
          <p className="ClientTestimonials-clientname">Rajesh Mishra</p>
          </div>
      </Carousel.Item>
      <Carousel.Item>
          <h2 className="ClientTestimonials-head">CLIENT TESTIMONIALS</h2>
          <div className="ClientTestimonials-padding">
          <img src={user} alt="user"/>
          <p className="ClientTestimonials-info">" Best Real estate company in Mumbai.. Sales staff is very cooperative and highly professional.. 
          Thanxx Basera Estate Consultants for my Dream Home  "</p><br/>
          <p className="ClientTestimonials-clientname">Rajesh Mishra</p>
          </div>
      </Carousel.Item>
      <Carousel.Item>
          <h2 className="ClientTestimonials-head">CLIENT TESTIMONIALS</h2>
          <div className="ClientTestimonials-padding">
          <img src={user} alt="user"/>
          <p className="ClientTestimonials-info">" Best Real estate company in Mumbai.. Sales staff is very cooperative and highly professional.. 
          Thanxx Basera Estate Consultants for my Dream Home  "</p><br/>
          <p className="ClientTestimonials-clientname">Rajesh Mishra</p>
          </div>
      </Carousel.Item>
    </Carousel>
    </section>
  );
};

export default ClientTestimonials;
