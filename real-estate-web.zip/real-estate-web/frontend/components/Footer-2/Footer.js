import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import homeLogo from "../../assets/Footer-2/home-logo-footer.svg";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import CallIcon from "@mui/icons-material/Call";
import EmailIcon from "@mui/icons-material/Email";
import TwitterIcon from "@mui/icons-material/Twitter";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import Button from "react-bootstrap/Button";
import "./Footer.css";

const navdata = [
  {
    id: 0,
    name: "Home",
  },
  {
    id: 1,
    name: "Properties Right",
  },
  {
    id: 2,
    name: "Properties List",
  },
  {
    id: 3,
    name: "Property Details",
  },
  {
    id: 4,
    name: "Agents Listing",
  },
];
const navdata2 = [
  {
    id: 0,
    name: "Property Details",
  },
  {
    id: 1,
    name: "About Us",
  },
  {
    id: 2,
    name: "Blog Default",
  },
  {
    id: 3,
    name: "Blog Details",
  },
  {
    id: 4,
    name: "Contact Us",
  },
];

const twitdata = [
  {
    id: 0,
    link: "#",
    msg: "All Share Them With Me Baby Said Inspet",
    time: "about 5 days ago",
  },
  {
    id: 1,
    link: "#",
    msg: "All Share Them With Me Baby Said Inspet",
    time: "about 5 days ago",
  },
  {
    id: 2,
    link: "#",
    msg: "All Share Them With Me Baby Said Inspet",
    time: "about 5 days ago",
  },
];

const Footer = () => {
  return (
    <section className="Footer-section">
      <Container>
        <Row>
          <Col xs={12} md={3}>
            <div className="Footer-left-top">
              <a href="#" className="Footer-home-logo">
                <img src={homeLogo} />
              </a>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum
                incidunt architecto soluta laboriosam, perspiciatis, aspernatur
                officiis esse.
              </p>
            </div>
            <div className="Footer-left-contactus">
              <ul>
                <li>
                  <LocationOnIcon fontSize="small" /> 95 South Park Avenue, USA
                </li>
                <li>
                  <CallIcon fontSize="small" /> +91 99999 99999
                </li>
                <li>
                  <EmailIcon fontSize="small" /> support@findhouses.com
                </li>
              </ul>
            </div>
          </Col>
          <Col xs={12} md={3}>
            <div className="Footer-navigation">
              <h3>Navigation</h3>
              <div className="Footer-navigation-names">
                <ul>
                  {navdata.map((names) => (
                    <li key={names.id}>
                      <a href="#">{names.name}</a>
                    </li>
                  ))}
                </ul>
                <ul className="Footer-navigation-right-name">
                  {navdata2.map((names) => (
                    <li key={names.id}>
                      <a href="#">{names.name}</a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Col>
          <Col xs={12} md={3}>
            <h3>Twitter Feeds</h3>
            {twitdata.map((twit) => (
              <div className="Footer-twitter-area" key={twit.id}>
                <div className="Footer-twitter-signal">
                  <div>
                    <TwitterIcon fontSize="small" />
                  </div>
                  <div>
                    <a href={twit.link}>@Findhouses</a> {twit.msg}
                  </div>
                </div>
                <h5>{twit.time}</h5>
              </div>
            ))}
          </Col>
          <Col xs={12} md={3}>
            <h3>Newsletters</h3>
            <div className="Footer-newsletter">
              <p>
                Sign Up for Our Newsletter to get Latest Updates and Offers.
                Subscribe to receive news in your inbox.
              </p>
              <div>
                <InputGroup>
                  <Form.Control
                    className="Footer-newsletter-email"
                    placeholder="Enter Your Email"
                  />
                  <Button>
                  SUBSCRIBE
                  </Button>
                </InputGroup>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default Footer;
