import React from 'react'
import Box from "@mui/material/Box";

const AddProperty = () => {
  return (
    <>
        <Box height={100}/>
        <div>hiiiiii </div>
    </>
  )
}

export default AddProperty