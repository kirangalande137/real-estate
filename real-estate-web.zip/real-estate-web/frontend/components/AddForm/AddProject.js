import React, { useState, useRef } from "react";
import Box from "@mui/material/Box";
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import * as formik from "formik";
import * as yup from "yup";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import "./AddProject.css";
import CustomSelect from "./CustomSelect";
import CustomInput from "./CustomInput";
import { AddProjectType } from "../../hooks/AddProjectType/useAddProjectType";
const AddProject = () => {
  const { Formik } = formik;

  const schema = yup.object().shape({
    projectName: yup.string().required("Project Name is Requried"),
    subTittle: yup.string().required("Sub Tittle is Requried"),
    projectType: yup.string().required("Project Type is Requried"),
    projectCategory: yup.string().required("Project Category is Requried"),
    projectStatus: yup.string().required("Project Status is Requried"),
    // builderName: yup.string().required("Builder Name is Requried"),
    availableForm: yup.string().required("Available Form is Requried"),
    // reraNum: yup.string().required("RERA number is Requried"),
    // projectprice: yup.string().required("Project Price is Requried"),
    parking: yup.string().required("Parking is Requried"),
    // description: yup.string().required("Description is Required"),
    videolink: yup.string().required("Video link is Requried"),
    // featuredimage: yup.string().required("Featured Image is Requried"),
    // selectimg: yup.string().required(),
    selectstate: yup.string().required("Select State is Requried"),
    selectcity: yup.string().required("Select City is Requried"),
    location: yup.string().required("Location is Requried"),
    address: yup.string().required("Address is Requried"),
    disclaimber: yup.string().required("Disclaimber is Requried"),
    comments: yup.string().required("Comments is Requried"),
    // amenities: yup.array().required("Select Amenities is Requried"),
    selectFeatured: yup.string().required("Select Featured is Requried"),
    selectVisibilty: yup.string().required("Select Visibilty is Requried"),
  });



  //editor
  // const [editorValue, setEditorValue] = useState("");

  //choose file
  const [selectedImage, setSelectedImage] = useState(null);
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      // You can use FileReader to read the selected image
      const reader = new FileReader();
      reader.onloadend = () => {
        // After reading the file, set it to the state
        setSelectedImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  //mapping aminities data
  const amenitiesdata1 = [
    { label: "amenitie 1", value: "amenitie 1" },
    { label: "amenitie 2", value: "amenitie 2" },
    { label: "amenitie 3", value: "amenitie 3" },
    { label: "amenitie 4", value: "amenitie 4" },
    { label: "amenitie 5", value: "amenitie 5" },
    { label: "amenitie 6", value: "amenitie 6" },
  ];
  //mapping data
  const projecttypedata = [
    { id: 0, label: "Type 1" },
    { id: 1, label: "Type 2" },
    { id: 2, label: "Type 3" },
  ];
  const projectcategorydata = [
    { id: 0, label: "Category 1" },
    { id: 1, label: "Category 2" },
    { id: 2, label: "Category 3" },
  ];
  const projectstatusdata = [
    { id: 0, label: "Status 1" },
    { id: 1, label: "Status 2" },
    { id: 2, label: "Status 3" },
  ];
  const projectavailableformdata = [
    { id: 0, label: "Form 1" },
    { id: 1, label: "Form 2" },
    { id: 2, label: "Form 3" },
  ];
  const parkingdata = [
    { id: 0, label: "Parking 1" },
    { id: 1, label: "Parking 2" },
    { id: 2, label: "Parking 3" },
  ];
  const selectstatedata = [
    { id: 0, label: "Country 1" },
    { id: 1, label: "Country 2" },
    { id: 2, label: "Country 3" },
  ];
  const selectcitydata = [
    { id: 0, label: "City 1" },
    { id: 1, label: "City 2" },
    { id: 2, label: "City 3" },
  ];
  const projectfeatureddata = [
    { id: 0, label: "Featured 1" },
    { id: 1, label: "Featured 2" },
    { id: 2, label: "Featured 3" },
  ];
  const projectvisbilitydata = [
    { id: 0, label: "Visibility 1" },
    { id: 1, label: "Visibility 2" },
    { id: 2, label: "Visibility 3" },
  ];

  //send data to hook
  const { mutate } = AddProjectType();
  //to give data form frontend and pass to hook for backend using mutation
  const AddSubmit = (values) => {
    // console.log(values);
    mutate(values, {});
  };

  return (
    <>
      <Box height={50} />
      <h1 className="addproject-heading">Add Project Basic Details</h1>
      <Formik
        validationSchema={schema}
        onSubmit={AddSubmit}
        initialValues={{
          projectName: "",
          subTittle: "",
          projectType: "",
          projectCategory: "",
          projectStatus: "",
          builderName: "",
          availableForm: "",
          reraNum: "",
          projectprice: "",
          parking: "",
          description: "",
          videolink: "",
          featuredimage: "",
          selectimg: "",
          selectstate: "",
          selectcity: "",
          location: "",
          address: "",
          amenities: [],
          disclaimber: "",
          comments: "",
          selectFeatured: "",
          selectVisibilty: "",
        }}
      >
        {({ handleSubmit, handleChange, values, touched, errors }) => (
          <Form noValidate onSubmit={handleSubmit}>
            <Row className="mb-4">
              <Col xs={12} md={5}>
                <CustomInput
                  heading="Project Name *"
                  type="text"
                  name="projectName"
                  error={errors.projectName}
                  value={values.projectName}
                  onChange={handleChange}
                />
              </Col>
              <Col xs={12} md={5}>
                <CustomInput
                  heading="Sub Tittle *"
                  type="text"
                  name="subTittle"
                  error={errors.subTittle}
                  value={values.subTittle}
                  onChange={handleChange}
                />
              </Col>
            </Row>
            <Row className="mb-4">
              <Col xs={12} md={4}>
                <CustomSelect
                  heading="Project Type *"
                  placeholder="Project Type"
                  name="projectType"
                  value={values.projectType}
                  onChange={handleChange}
                  error={errors.projectType}
                  options={projecttypedata}
                />
              </Col>
              <Col xs={12} md={4}>
                <CustomSelect
                  heading="Project Category *"
                  placeholder="Project Category"
                  name="projectCategory"
                  value={values.projectCategory}
                  onChange={handleChange}
                  error={errors.projectCategory}
                  options={projectcategorydata}
                />
              </Col>
              <Col xs={12} md={4}>
                <CustomSelect
                  heading="Project Status *"
                  placeholder="Project Status"
                  name="projectStatus"
                  value={values.projectStatus}
                  onChange={handleChange}
                  error={errors.projectStatus}
                  options={projectstatusdata}
                />
              </Col>
            </Row>
            <Row className="mb-4">
              <Col xs={12} md={4}>
                <CustomInput
                  heading="Builder/Developer Name"
                  type="text"
                  name="builderName"
                  // error={errors.builderName}
                  value={values.builderName}
                  onChange={handleChange}
                />
              </Col>
              <Col xs={12} md={4}>
                <CustomSelect
                  heading="Available Form *"
                  placeholder="Available Form"
                  name="availableForm"
                  value={values.availableForm}
                  onChange={handleChange}
                  error={errors.availableForm}
                  options={projectavailableformdata}
                />
              </Col>
              <Col xs={12} md={4}>
                <CustomInput
                  heading="RERA Rang No."
                  type="text"
                  name="reraNum"
                  // error={errors.reraNum}
                  value={values.reraNum}
                  onChange={handleChange}
                />
              </Col>
            </Row>
            <Row className="mb-4">
              <Col xs={12} md={4}>
                <CustomInput
                  heading="Project Price"
                  type="number"
                  name="projectprice"
                  // error={errors.projectprice}
                  value={values.projectprice}
                  onChange={handleChange}
                />
              </Col>
              <Col xs={12} md={4}>
                <CustomSelect
                  heading="Parking *"
                  placeholder="Parking"
                  name="parking"
                  value={values.parking}
                  onChange={handleChange}
                  error={errors.parking}
                  options={parkingdata}
                />
              </Col>
            </Row>
            <Row className="mb-4">
              <Col xs={12} md={10}>
                <Form.Group controlId="validationFormik">
                  <Form.Label>Description </Form.Label>
                  <ReactQuill
                    name="description"
                    value={values.description}
                    onChange={(content) =>
                      handleChange({
                        target: { name: "description", value: content },
                      })
                    }
                    modules={{
                      toolbar: [
                        [{ header: [1, 2, false] }],
                        ["bold", "italic", "underline", "strike", "blockquote"],
                        [{ list: "ordered" }, { list: "bullet" }],
                        ["link", "image"],
                        ["clean"],
                      ],
                    }}
                    formats={[
                      "header",
                      "bold",
                      "italic",
                      "underline",
                      "strike",
                      "blockquote",
                      "list",
                      "bullet",
                      "link",
                      "image",
                    ]}
                    placeholder="Description..."
                    style={{ height: "200px", paddingBottom: "40px" }}
                    // isInvalid={!!errors.description}
                  />
                  {/* <Form.Control.Feedback type="invalid">
                    {errors.description}
                  </Form.Control.Feedback> */}
                </Form.Group>
              </Col>
            </Row>
            <Row className="mb-4">
              <Col xs={12} md={5}>
                <CustomInput
                  heading="Video Link *"
                  type="link"
                  name="videolink"
                  error={errors.videolink}
                  value={values.videolink}
                  onChange={handleChange}
                />
              </Col>
              <Col xs={12} md={5}>
                <Form.Group controlId="validationFormik">
                  <Form.Label>Featured image *</Form.Label>
                  <div className="addproject-featuredimg">
                    <input
                      name="featuredimage"
                      value={values.featuredimage}
                      isInvalid={!!errors.featuredimage}
                      type="file"
                      accept="image/*"
                      onChange={handleChange}
                    />
                    {selectedImage && (
                      <div>
                        <p>Selected Image</p>
                        <img
                          name="selectimg"
                          src={selectedImage}
                          alt="Selected"
                          style={{ maxWidth: "100%", maxHeight: "200px" }}
                        />
                      </div>
                    )}
                  </div>
                  <Form.Control.Feedback type="invalid">
                    {errors.featuredimage}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row className="mb-4">
              <Col xs={12} md={4}>
                <CustomSelect
                  heading="Select State/Country *"
                  placeholder="Select State/Country"
                  name="selectstate"
                  value={values.selectstate}
                  onChange={handleChange}
                  error={errors.selectstate}
                  options={selectstatedata}
                />
              </Col>
              <Col xs={12} md={4}>
                <CustomSelect
                  heading="Select City *"
                  placeholder="Select City"
                  name="selectcity"
                  value={values.selectcity}
                  onChange={handleChange}
                  error={errors.selectcity}
                  options={selectcitydata}
                />
              </Col>
              <Col xs={12} md={4}>
                <CustomInput
                  heading="Location *"
                  type="text"
                  name="location"
                  error={errors.location}
                  value={values.location}
                  onChange={handleChange}
                />
              </Col>
            </Row>
            <Row className="mb-4">
              <Col xs={12} md={10}>
                <Form.Group controlId="validationFormik">
                  <Form.Label>Address *</Form.Label>
                  <Form.Control
                    type="text"
                    name="address"
                    value={values.address}
                    onChange={handleChange}
                    isInvalid={!!errors.address}
                    placeholder="Enter Address"
                    required
                    as="textarea"
                    style={{ height: "100px" }}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.address}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row className="mb-4">
              <Form.Group controlId="validationFormik">
                <Form.Label>Amenities *</Form.Label>
                <Col xs={6} md={10}>
                  {amenitiesdata1.map((data) => (
                    <Form.Check
                      key={data.value}
                      inline
                      label={data.label}
                      type="checkbox"
                      name="amenities"
                      value={values.amenities}
                      onChange={() => {
                        const isChecked = values.amenities.includes(data.value);
                        // Update Formik state based on checkbox status
                        handleChange({
                          target: {
                            name: "amenities",
                            value: isChecked
                              ? values.amenities.filter(
                                  (value) => value !== data.value
                                )
                              : [...values.amenities, data.value],
                          },
                        });
                      }}
                      checked={values.amenities.includes(data.value)}
                    />
                  ))}
                </Col>
              </Form.Group>
            </Row>
            <Row className="mb-4">
              <Col xs={12} md={6}>
                <Form.Group controlId="validationFormik">
                  <Form.Label>Disclaimber </Form.Label>
                  <Form.Control
                    type="text"
                    name="disclaimber"
                    value={values.disclaimber}
                    onChange={handleChange}
                    isInvalid={!!errors.disclaimber}
                    placeholder="Disclaimber"
                    required
                    as="textarea"
                    style={{ height: "100px" }}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.disclaimber}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col xs={12} md={6}>
                <Form.Group controlId="validationFormik">
                  <Form.Label>Comments </Form.Label>
                  <Form.Control
                    type="text"
                    name="comments"
                    value={values.comments}
                    onChange={handleChange}
                    isInvalid={!!errors.comments}
                    placeholder="Comments"
                    required
                    as="textarea"
                    style={{ height: "100px" }}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.comments}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            <Row className="mb-4">
              <Col xs={12} md={4}>
                <CustomSelect
                  heading="Featured *"
                  placeholder="Featured"
                  name="selectFeatured"
                  value={values.selectFeatured}
                  onChange={handleChange}
                  error={errors.selectFeatured}
                  options={projectfeatureddata}
                />
              </Col>
              <Col xs={12} md={4}>
                <CustomSelect
                  heading="Visbility *"
                  placeholder="Visbility"
                  name="selectVisibilty"
                  value={values.selectVisibilty}
                  onChange={handleChange}
                  error={errors.selectVisibilty}
                  options={projectvisbilitydata}
                />
              </Col>
            </Row>
            <div className="addproject-submit-btn">
              <Button type="submit">Submit form</Button>
            </div>
          </Form>
        )}
      </Formik>
    </>
  );
};

export default AddProject;
