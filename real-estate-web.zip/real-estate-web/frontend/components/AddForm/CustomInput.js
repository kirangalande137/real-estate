import React from "react";
import Form from "react-bootstrap/Form";

const CustomInput = (props) => {
  return (
    <Form.Group controlId="validationFormik">
      <Form.Label>{props.heading}</Form.Label>
      <Form.Control
        type={props.type}
        name={props.name}
        value={props.value}
        onChange={props.onChange}
        isInvalid={!!props.error}
        placeholder="Project Name"
        // required
      />
      <Form.Control.Feedback type="invalid">
        {props.error}
      </Form.Control.Feedback>
    </Form.Group>
  );
};

export default CustomInput;
