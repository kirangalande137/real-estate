import React from "react";
import Form from "react-bootstrap/Form";
const CustomSelect = (props) => {
  return (
    <Form.Group controlId="validationFormik">
    <Form.Label>{props.heading}</Form.Label>
    <Form.Select
      name={props.name}
      value={props.value} 
      onChange={props.onChange}
      isInvalid={!!props.error}
    >
      <option value="" disabled>{props.placeholder}</option>
      {props.options.map((data) => (
        <option key={data.id}>
          {data.label}
        </option>
      ))}
    </Form.Select>
    <Form.Control.Feedback type="invalid">
      {props.error}
    </Form.Control.Feedback> 
  </Form.Group>
  );
};

export default CustomSelect;
