import * as React from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import Carousel from "react-bootstrap/Carousel";
import banner1 from "../../assets/slider/banner1.jpg";
import banner2 from "../../assets/slider/banner2.jpg";
import banner3 from "../../assets/slider/banner3.jpg";
import banner4 from "../../assets/slider/banner4.jpg";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import SearchIcon from "@mui/icons-material/Search";
import "./hero2.css";

const projectType = [
  { label: "Project type" },
  { label: "Residential", link: "/residential" },
  { label: "Commercial", link: "/commercial" },
];

const projectStatus = [
  { label: "Project Status" },
  { label: "New Project", link: "/new-project" },
  { label: "Under Construction", link: "/under-construction" },
  { label: "Ready to move", link: "/ready-to-move" },
];

const configuration = [
  { label: "1BHK", link: "/1bhk" },
  { label: "2BHK", link: "/2bhk" },
  { label: "3BHK", link: "/3bhk" },
];

const location = [{ label: "location", link: "/location" }];

const sliderdata = [
  {
    id: 0,
    banner: banner1,
  },
  {
    id: 1,
    banner: banner2,
  },
  {
    id: 2,
    banner: banner3,
  },
  {
    id: 3,
    banner: banner4,
  },
];

const hero2 = () => {
  return (
    <section className="hero2-section">
      <div className="hero2-slider">
     
        <Carousel>
          {sliderdata.map((data) => (
            <Carousel.Item interval={1000} key={data.id}>
              <div className="hero2-slider-img"><img src={data.banner} width="100%" height="auto" alt="banner" /></div>
              <div class="hero2-centered">Basera Estate Consultants</div>
            </Carousel.Item>
          ))}
          {/* <Carousel.Item interval={500}>
            <img src={banner2} width="100%" height="auto" alt="banner2" />
          </Carousel.Item>
          <Carousel.Item>
            <img src={banner3} width="100%" height="auto" alt="banner3" />
          </Carousel.Item>
          <Carousel.Item>
            <img src={banner4} width="100%" height="auto" alt="banner4" />
          </Carousel.Item> */}
        </Carousel>
        {/* <Carousel.Caption>
              <h3>First slide label</h3>
              <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
            </Carousel.Caption> */}
      </div>
      <div className="hero2-tabs-display">
        <div className="hero2-tabs">
          <Tabs
            defaultActiveKey="projecttype"
            id="uncontrolled-tab-example"
            className="mb-3"
          >
            <Tab eventKey="projecttype" title="Project Type">
              <Container>
                <Row className="hero2-dropdown-text">
                  <Col xs={2} className="hero2-select-field">
                    <Autocomplete
                      disablePortal
                      // id="combo-box-demo"
                      options={projectType}
                      // sx={{ width: 200 }}
                      renderInput={(params) => (
                        <TextField {...params} label="Project Type" />
                      )}
                    />
                  </Col>
                  <Col xs={2} className="hero2-select-field">
                    <Autocomplete
                      disablePortal
                      options={projectStatus}
                      renderInput={(params) => (
                        <TextField {...params} label="Project Status" />
                      )}
                    />
                  </Col>
                  <Col xs={2} className="hero2-select-field">
                    <Autocomplete
                      disablePortal
                      options={configuration}
                      renderInput={(params) => (
                        <TextField {...params} label="Configuration" />
                      )}
                    />
                  </Col>
                  <Col xs={2} className="hero2-select-field">
                    <Autocomplete
                      disablePortal
                      options={location}
                      renderInput={(params) => (
                        <TextField {...params} label="Location" />
                      )}
                    />
                  </Col>
                  <Col xs={3} className="hero2-select-field-button">
                    <button
                      type="submit"
                      name="submit"
                      className="btn text-capitalize pull-right "
                    >
                      Search Project&nbsp;&nbsp;
                      <SearchIcon />
                    </button>
                  </Col>
                </Row>
              </Container>
            </Tab>
            <Tab eventKey="profile" title="Property Type">
              <Container>
                <Row className="hero2-dropdown-text">
                  <Col xs={2} className="hero2-select-field">
                    <Autocomplete
                      disablePortal
                      // id="combo-box-demo"
                      options={projectType}
                      // sx={{ width: 200 }}
                      renderInput={(params) => (
                        <TextField {...params} label="Project Type" />
                      )}
                    />
                  </Col>
                  <Col xs={2} className="hero2-select-field">
                    <Autocomplete
                      disablePortal
                      options={projectStatus}
                      renderInput={(params) => (
                        <TextField {...params} label="Project Status" />
                      )}
                    />
                  </Col>
                  <Col xs={2} className="hero2-select-field">
                    <Autocomplete
                      disablePortal
                      options={configuration}
                      renderInput={(params) => (
                        <TextField {...params} label="Configuration" />
                      )}
                    />
                  </Col>
                  <Col xs={2} className="hero2-select-field">
                    <Autocomplete
                      disablePortal
                      options={location}
                      renderInput={(params) => (
                        <TextField {...params} label="Location" />
                      )}
                    />
                  </Col>
                  <Col xs={3} className="hero2-select-field-button">
                    <button
                      type="submit"
                      name="submit"
                      className="btn text-capitalize pull-right "
                    >
                      Search Property&nbsp;&nbsp;
                      <SearchIcon />
                    </button>
                  </Col>
                </Row>
              </Container>
            </Tab>
          </Tabs>
        </div>
      </div>
    </section>
  );
};

export default hero2;
