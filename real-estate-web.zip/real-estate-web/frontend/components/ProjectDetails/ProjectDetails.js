import React from 'react'

const ProjectDetails = () => {
  return (
    <section className='project-section'>
        ProjectDetails
    </section>
  )
}

export default ProjectDetails