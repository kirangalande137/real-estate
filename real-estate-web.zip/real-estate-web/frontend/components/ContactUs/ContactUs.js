import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { Button, FloatingLabel } from "react-bootstrap";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import EmailIcon from "@mui/icons-material/Email";
import PhoneIcon from "@mui/icons-material/Phone";
import "./ContactUs.css";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";

const ContactUs = () => {

  const initialValues = {
    name: '',
    phoneNumber: '',
    email: '',
    subject: '',
    message: '',
    verify: '',
    checkbox: false,
  };

  const validationSchema = Yup.object({
    name: Yup.string().required('Name is required'),
    phoneNumber: Yup.string().required('Phone Number is required'),
    email: Yup.string().email('Invalid email format').required('Email is required'),
    subject: Yup.string().required('Subject is required'),
    message: Yup.string().required('Message is required'),
    verify: Yup.string()
      .oneOf(['22'], 'Incorrect verification answer')
      .required('Verification is required'),
    checkbox: Yup.boolean().oneOf([true], 'You must accept the terms and conditions'),
  });

  const onSubmit = (values, { resetForm }) => {
    console.log('Form data', values);
    resetForm();
  };

  return (
    <div>
      <Container>
        <Row>
          <Col xs={12} md={6}>
            <div className="ContactUs-form">
              <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={onSubmit}
              >
                {({ resetForm }) => (
                  <Form>
                    <h3 className="ContactUs-head">CONNECT WITH US</h3>
                    <p className="ContactUs-head-caption">
                      To discuss how we can help you, send us an email.
                    </p>
                    <div className="mb-3">
                      <label htmlFor="name">Name</label>
                      <Field
                        type="text"
                        id="name"
                        name="name"
                        placeholder="Enter name"
                        className="form-control"
                      />
                      <ErrorMessage
                        name="name"
                        component="div"
                        className="text-danger"
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="phoneNumber">Phone Number</label>
                      <Field
                        type="text"
                        id="phoneNumber"
                        name="phoneNumber"
                        placeholder="Enter phone number"
                        className="form-control"
                      />
                      <ErrorMessage
                        name="phoneNumber"
                        component="div"
                        className="text-danger"
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="email">Email address</label>
                      <Field
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Enter email"
                        className="form-control"
                      />
                      <ErrorMessage
                        name="email"
                        component="div"
                        className="text-danger"
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="subject">Enter Subject</label>
                      <Field
                        type="text"
                        id="subject"
                        name="subject"
                        placeholder="Enter subject"
                        className="form-control"
                      />
                      <ErrorMessage
                        name="subject"
                        component="div"
                        className="text-danger"
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="message">Enter Message</label>
                      <FloatingLabel
                        controlId="floatingTextarea2"
                        label="Enter Message"
                      >
                        <Field
                          as="textarea"
                          id="message"
                          name="message"
                          style={{ height: "100px" }}
                          className="form-control"
                        />
                      </FloatingLabel>
                      <ErrorMessage
                        name="message"
                        component="div"
                        className="text-danger"
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="verify">12+10 =</label>
                      <Field
                        type="text"
                        id="verify"
                        name="verify"
                        placeholder="Please verify"
                        className="form-control"
                      />
                      <ErrorMessage
                        name="verify"
                        component="div"
                        className="text-danger"
                      />
                    </div>
                    <div className="mb-3">
                      <Field
                        type="checkbox"
                        id="checkbox"
                        name="checkbox"
                        className="form-check-input"
                      />
                      <label htmlFor="checkbox" className="form-check-label">
                        Accept terms and conditions
                      </label>
                      <ErrorMessage
                        name="checkbox"
                        component="div"
                        className="text-danger"
                      />
                    </div>
                    <div className="ContactUs-form-submitbtn">
                      <Button
                        type="submit"
                        className="ContactUs-form-submitbtn1"
                      >
                        Submit
                      </Button>
                      <Button
                        type="reset"
                        onClick={resetForm}
                        className="ContactUs-form-submitbtn2"
                      >
                        Reset
                      </Button>
                    </div>
                  </Form>
                )}
              </Formik>
            </div>
          </Col>
          <Col xs={12} md={6}>
            <div className="ContactUs-map">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30153.788310373093!2d72.82012479640191!3d19.14168989610612!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b63aceef0c69%3A0x2aa80cf2287dfa3b!2sJogeshwari%20West%2C%20Mumbai%2C%20Maharashtra%20400047!5e0!3m2!1sen!2sin!4v1699355316010!5m2!1sen!2sin"
                width="100%"
                height="450"
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
            <div>
              <h4>Contact Details</h4>
              <p>
                <b className="ContactUs-address">
                  <LocationOnIcon /> Address:{" "}
                </b>
                Shop No 5, Roop Apartment, Off S V Road, Below Ruby Hospital,
                Jogeshwari West, Mumbai - 400102.
              </p>
              <p>
                <b className="ContactUs-address">
                  <EmailIcon /> Email:{" "}
                </b>
                info@baseraestate.co.in
              </p>
              <p>
                <b className="ContactUs-address">
                  <PhoneIcon /> Phone:{" "}
                </b>
                +91 99999 99999
              </p>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default ContactUs;
