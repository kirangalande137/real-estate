import React from "react";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import logo from "../../assets/logo/logo.png";

import "./Header.css";
import { NavLink } from "react-bootstrap";

const aboutusSubMenu = [

    { name: "ABOUT", link: "/about" },
    { name: "AWARDS & CERTIFICATES", link: "/awards-certificates"},
    { name: "EVENT GALLERY", link: "/events-gallery"}

];

const projectSubMenu = [
 { name: "ADD PROJECT", link: "/addproject" },
 { name: "READY TO MOVE", link: "/ready-to-move" },
 { name: "UNDERCONSTRUCTION", link: "/underconstruction"},
 { name: "UPCOMING", link: "/upcoming"}

];

const buysellSubMenu = [

    { name: "POST YOUR REQURIMENT", link: "/post-your-requriment" },
    { name: "POST YOUR PROPERTY", link: "/post-your-property"},
   
];

const propertySubMenu = [

    { name: "RESIDENTIAL", link: "/residential" },
    { name: "COMMERCIAL", link: "/commercial"},
   
];

const navdata = [
  { name: "HOME", link: "/home", submenu: false , submenuarray: null },
  { name: "ABOUT US", link: "/about", submenu: true ,submenuarray: aboutusSubMenu},
  { name: "SERVICES", link: "/services", submenu: false ,submenuarray: null},
  { name: "PROPERTIES", link: "/properties", submenu: true,submenuarray: propertySubMenu },
  { name: "PROJECT", link: "/project", submenu: true,submenuarray: projectSubMenu },
  { name: "BUY & SELL", link: "/buy&sell", submenu: true,submenuarray: buysellSubMenu },
  { name: "BLOG", link: "/blog", submenu: false,submenuarray: null },
  { name: "CAREER", link: "/career", submenu: false,submenuarray: null },
  { name: "CONTACT US", link: "/contact us", submenu: false ,submenuarray: null},
  { name: "LOGIN", link: "/loginpage", submenu: false,submenuarray: null },
];

function Header() {
  return (
    <Navbar expand="lg" className="bg-body-tertiary ">
      <Container fluid>
        <Navbar.Brand href="#" className="Header-logo">
          <img src={logo} width="100%" height="auto" alt="Logo" />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <>
            <Nav
              className="Header-menu my-2 my-lg-0"
              style={{
                width: " 100%",
                justifyContent: "end",
                fontWeight: "700",
              }}
              navbarScroll
            >
              {navdata.map((row, index) => //map navdata
                row.submenu ? ( // dropdown present(ternary operator)
                  <NavDropdown title={row.name} id="navbarScrollingDropdown" key={index} className="Header-dropdown" >
                    {row.submenuarray.map((submenurow,submenuindex) =>
                    <NavDropdown.Item href={submenurow.link} key={submenuindex} className="Header-dropdownmenu"> 
                      {submenurow.name}
                    </NavDropdown.Item>
                    )}
                  </NavDropdown>
                ) : (  //not dropdown present
                  <NavLink href={row.link} className="" key={index}>
                    {row.name}
                  </NavLink>
                )
              )}
            </Nav>
          </>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;





// import React from "react";
// import Container from "react-bootstrap/Container";
// import Nav from "react-bootstrap/Nav";
// import Navbar from "react-bootstrap/Navbar";
// import NavDropdown from "react-bootstrap/NavDropdown";
// import logo from "../../assets/logo/logo.png";

// import "./Header.css";

// const aboutusSubMenu = [

//     { name: "ABOUT", link: "/about" },
//     { name: "AWARDS & CERTIFICATES", link: "/awards-certificates"},
//     { name: "EVENT GALLERY", link: "/events-gallery"}

// ];

// const projectSubMenu = [

//  { name: "READY TO MOVE", link: "/ready-to-move" },
//  { name: "UNDERCONSTRUCTION", link: "/underconstruction"},
//  { name: "UPCOMING", link: "/upcoming"}

// ];

// const buysellSubMenu = [

//     { name: "POST YOUR REQURIMENT", link: "/post-your-requriment" },
//     { name: "POST YOUR PROPERTY", link: "/post-your-property"},
   
// ];

// const propertySubMenu = [

//     { name: "RESIDENTIAL", link: "/residential" },
//     { name: "COMMERCIAL", link: "/commercial"},
   
// ];

// const navdata = [
//   { name: "HOME", link: "/home", submenu: false , submenuarray: null },
//   { name: "ABOUT US", link: "/about", submenu: true ,submenuarray: aboutusSubMenu},
//   { name: "SERVICES", link: "/services", submenu: false ,submenuarray: null},
//   { name: "PROPERTIES", link: "/properties", submenu: true,submenuarray: propertySubMenu },
//   { name: "PROJECT", link: "/project", submenu: true,submenuarray: projectSubMenu },
//   { name: "BUY & SELL", link: "/buy&sell", submenu: true,submenuarray: buysellSubMenu },
//   { name: "BLOG", link: "/blog", submenu: false,submenuarray: null },
//   { name: "CAREER", link: "/career", submenu: false,submenuarray: null },
//   { name: "CONTACT US", link: "/contact us", submenu: false ,submenuarray: null},
//   { name: "LOGIN", link: "/login", submenu: false,submenuarray: null },
// ];

// function Header() {
//   return (
//     <Navbar expand="lg" className="bg-body-tertiary ">
//       <Container fluid>
//         <Navbar.Brand href="#" className="Header-logo">
//           <img src={logo} width="100%" height="auto" alt="Logo" />
//         </Navbar.Brand>
//         <Navbar.Toggle aria-controls="navbarScroll" />
//         <Navbar.Collapse id="navbarScroll">
//           <>
//             <Nav
//               className="main-head my-2 my-lg-0"
//               style={{
//                 width: " 100%",
//                 justifyContent: "end",
//                 fontWeight: "700",
//               }}
//               navbarScroll
//             >
//               {navdata.map((row, index) => //map navdata
//                 row.submenu ? ( // dropdown present(ternary operator)
//                   <NavDropdown title={row.name} id="navbarScrollingDropdown" key={index} >
//                     {row.submenuarray.map((submenurow,submenuindex) =>
//                     <NavDropdown.Item href={submenurow.link} key={submenuindex} className="Header-dropdownmenu"> 
//                       {submenurow.name}
//                     </NavDropdown.Item>
//                     )}
//                   </NavDropdown>
//                 ) : (  //not dropdown present
//                   <Nav.Link href={row.link} className="" key={index}>
//                     {row.name}
//                   </Nav.Link>
//                 )
//               )}
//             </Nav>
//           </>
//         </Navbar.Collapse>
//       </Container>
//     </Navbar>
//   );
// }

// export default Header;