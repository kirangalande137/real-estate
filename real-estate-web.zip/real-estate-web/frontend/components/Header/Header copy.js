// import React from "react";
// import Button from "react-bootstrap/Button";
// import Container from "react-bootstrap/Container";
// import Form from "react-bootstrap/Form";
// import Nav from "react-bootstrap/Nav";
// import Navbar from "react-bootstrap/Navbar";
// import NavDropdown from "react-bootstrap/NavDropdown";
// import logo from "../../assets/logo/logo.png";

// import './Header.css';

// function Header() {
//   return (
//     <Navbar expand="lg" className="bg-body-tertiary ">
//       <Container fluid>
//         <Navbar.Brand href="#" style={{ width: " 20%" }}><img src={logo}
//                      width="100%" height="auto"
//                      alt="Logo" /></Navbar.Brand>
//         <Navbar.Toggle aria-controls="navbarScroll" />
//         <Navbar.Collapse id="navbarScroll">
//           <Nav
//             className="main-head my-2 my-lg-0"
//             style={{ width: " 100%", justifyContent: "end" , fontWeight :'700'}}
//             // style="width: 100%;justify-content: end;"
//             navbarScroll >
//             <Nav.Link href="#action1" className="main-head">HOME</Nav.Link>
//             {/* <Nav.Link href="#action2">Link</Nav.Link> */}
//             <NavDropdown title="ABOUT US" id="navbarScrollingDropdown">
//               <NavDropdown.Item href="#action3">About Us</NavDropdown.Item>
//               <NavDropdown.Item href="#action4">
//               Awards & Certificates
//               </NavDropdown.Item>
//               <NavDropdown.Item href="#action5">
//               Events Gallery
//               </NavDropdown.Item>
//               {/* <NavDropdown.Item href="#action5">
//               Awards & Certificates
//               </NavDropdown.Item> */}
//             </NavDropdown>
//             <Nav.Link href="#action2">SERVICES</Nav.Link>
//             <NavDropdown title="PROPERTIES" id="navbarScrollingDropdown">
//               <NavDropdown.Item href="#action3">Residential</NavDropdown.Item>
//               <NavDropdown.Item href="#action4">
//               Commercial
//               </NavDropdown.Item>
//               {/* <NavDropdown.Item href="#action5">
//                 Something else here
//               </NavDropdown.Item> */}
//             </NavDropdown>
//             <NavDropdown title="PROJECT" id="navbarScrollingDropdown">
//               <NavDropdown.Item href="#action5">Ready to move</NavDropdown.Item>
//               <NavDropdown.Item href="#action6">
//                 Under Constructor
//               </NavDropdown.Item>
//               <NavDropdown.Item href="#action7">
//                 Up Coming
//               </NavDropdown.Item>
//             </NavDropdown>
//             <NavDropdown title="BUY & SELL" id="navbarScrollingDropdown">
//               <NavDropdown.Item href="#action8">Action</NavDropdown.Item>
//               <NavDropdown.Item href="#action9">
//                 Another action
//               </NavDropdown.Item>
//               <NavDropdown.Item href="#action10">
//                 Something else here
//               </NavDropdown.Item>
//             </NavDropdown>
//             <Nav.Link href="#action11">BLOG</Nav.Link>
//             <Nav.Link href="#action12">CAREER</Nav.Link>
//             <Nav.Link href="#action13">CONTACT US</Nav.Link>
//           </Nav>
//           {/* <Form className="d-flex">
//             <Form.Control
//               type="search"
//               placeholder="Search"
//               className="me-2"
//               aria-label="Search"
//             />
//             <Button variant="outline-primary">Search</Button>
//           </Form> */}
//         </Navbar.Collapse>
//       </Container>
//     </Navbar>
//   );
// }

// export default Header;

import React from "react";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Form from "react-bootstrap/Form";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import logo from "../../assets/logo/logo.png";

import "./Header.css";

const navdata = [
  { name: "Home", link: "/home", submenu: false },
  { name: "About us", link: "/about", submenu: true },
  { name: "Services", link: "/services", submenu: false },
  { name: "Project", link: "/project", submenu: true },
  { name: "Buy & Sell", link: "/buy&sell", submenu: true },
  { name: "Properties", link: "/properties", submenu: true },
  { name: "Blog", link: "/blog", submenu: false },
  { name: "Career", link: "/career", submenu: false },
  { name: "Contact us", link: "/contact us", submenu: false },
  { name: "Login", link: "/login", submenu: false },
];

function Header() {
  return (
    <Navbar expand="lg" className="bg-body-tertiary ">
      <Container fluid>
        <Navbar.Brand href="#" style={{ width: " 20%" }}>
          <img src={logo} width="100%" height="auto" alt="Logo" />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="main-head my-2 my-lg-0"
            style={{ width: " 100%", justifyContent: "end", fontWeight: "700" }}
            // style="width: 100%;justify-content: end;"
            navbarScroll
          >
            <Nav.Link href="#action1" className="main-head">
              HOME
            </Nav.Link>
            {/* <Nav.Link href="#action2">Link</Nav.Link> */}
            <NavDropdown title="ABOUT US" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#action3">About Us</NavDropdown.Item>
              <NavDropdown.Item href="#action4">
                Awards & Certificates
              </NavDropdown.Item>
              <NavDropdown.Item href="#action5">
                Events Gallery
              </NavDropdown.Item>
              {/* <NavDropdown.Item href="#action5">
              Awards & Certificates
              </NavDropdown.Item> */}
            </NavDropdown>
            <Nav.Link href="#action2">SERVICES</Nav.Link>
            <NavDropdown title="PROPERTIES" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#action3">Residential</NavDropdown.Item>
              <NavDropdown.Item href="#action4">Commercial</NavDropdown.Item>
              {/* <NavDropdown.Item href="#action5">
                Something else here
              </NavDropdown.Item> */}
            </NavDropdown>
            <NavDropdown title="PROJECT" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#action5">Ready to move</NavDropdown.Item>
              <NavDropdown.Item href="#action6">
                Under Constructor
              </NavDropdown.Item>
              <NavDropdown.Item href="#action7">Up Coming</NavDropdown.Item>
            </NavDropdown>
            <NavDropdown title="BUY & SELL" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#action8">Action</NavDropdown.Item>
              <NavDropdown.Item href="#action9">
                Another action
              </NavDropdown.Item>
              <NavDropdown.Item href="#action10">
                Something else here
              </NavDropdown.Item>
            </NavDropdown>
            <Nav.Link href="#action11">BLOG</Nav.Link>
            <Nav.Link href="#action12">CAREER</Nav.Link>
            <Nav.Link href="#action13">CONTACT US</Nav.Link>
          </Nav>
          {/* <Form className="d-flex">
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
            />
            <Button variant="outline-primary">Search</Button>
          </Form> */}
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;






// import React from "react";
// import Button from "react-bootstrap/Button";
// import Container from "react-bootstrap/Container";
// import Form from "react-bootstrap/Form";
// import Nav from "react-bootstrap/Nav";
// import Navbar from "react-bootstrap/Navbar";
// import NavDropdown from "react-bootstrap/NavDropdown";
// import logo from "../../assets/logo/logo.png";

// import "./Header.css";

// const aboutusSubMenu = [

//     { name: "ABOUT", link: "/about" },
//     { name: "AWARDS & CERTIFICATES", link: "/awards-certificates"},
//     { name: "EVENT GALLERY", link: "/events-gallery"}

// ];

// const projectSubMenu = [

//  { name: "READY TO MOVE", link: "/ready-to-move" },
//  { name: "UNDERCONSTRUCTION", link: "/underconstruction"},
//  { name: "UPCOMING", link: "/upcoming"}

// ];

// const buysellSubMenu = [

//     { name: "POST YOUR REQURIMENT", link: "/post-your-requriment" },
//     { name: "POST YOUR PROPERTY", link: "/post-your-property"},
   
// ];

// const propertySubMenu = [

//     { name: "RESIDENTIAL", link: "/residential" },
//     { name: "COMMERCIAL", link: "/commercial"},
   
// ];

// const navdata = [
//   { name: "HOME", link: "/home", submenu: false , submenuarray: null },
//   { name: "ABOUT US", link: "/about", submenu: true ,submenuarray: aboutusSubMenu},
//   { name: "SERVICES", link: "/services", submenu: false ,submenuarray: null},
//   { name: "PROPERTIES", link: "/properties", submenu: true,submenuarray: propertySubMenu },
//   { name: "PROJECT", link: "/project", submenu: true,submenuarray: projectSubMenu },
//   { name: "BUY & SELL", link: "/buy&sell", submenu: true,submenuarray: buysellSubMenu },
//   { name: "BLOG", link: "/blog", submenu: false,submenuarray: null },
//   { name: "CAREER", link: "/career", submenu: false,submenuarray: null },
//   { name: "CONTACT US", link: "/contact us", submenu: false ,submenuarray: null},
//   { name: "LOGIN", link: "/login", submenu: false,submenuarray: null },
// ];

// function Header() {
//   return (
//     <Navbar expand="lg" className="bg-body-tertiary ">
//       <Container fluid>
//         <Navbar.Brand href="#" className="logop">
//           <img src={logo} width="100%" height="auto" alt="Logo" />
//         </Navbar.Brand>
//         <Navbar.Toggle aria-controls="navbarScroll" />
//         <Navbar.Collapse id="navbarScroll">
//           <>
//             <Nav
//               className="main-head my-2 my-lg-0"
//               style={{
//                 width: " 100%",
//                 justifyContent: "end",
//                 fontWeight: "700",
//               }}
//               navbarScroll
//             >
//               {navdata.map((row, index) => //map navdata
//                 row.submenu ? ( // dropdown present(ternary operator)
//                   <NavDropdown title={row.name} id="navbarScrollingDropdown" key={index}>
//                     {row.submenuarray.map((submenurow,submenuindex) =>
//                     <NavDropdown.Item href={submenurow.link} key={submenuindex}> 
//                       {submenurow.name}
//                     </NavDropdown.Item>
//                     )}
//                   </NavDropdown>
//                 ) : (  //not dropdown present
//                   <Nav.Link href={row.link} className="main-head" key={index}>
                  
//                     {row.name}
//                   </Nav.Link>
//                 )
//               )}
//             </Nav>
//           </>
//         </Navbar.Collapse>
//       </Container>
//     </Navbar>
//   );
// }

// export default Header;