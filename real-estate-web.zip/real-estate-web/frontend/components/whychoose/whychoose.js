import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import project1 from "../../assets/whychoose/project1.jpg";
import project2 from "../../assets/whychoose/project2.png";
import project3 from "../../assets/whychoose/project3.png";
import project4 from "../../assets/whychoose/project4.png";

import "./whychoose.css";

const data1 = [
  {
    id:0,
    image:project1,
    name: "CUSTOMER-ORIENTED OUTLOOK",
    info: "Customer is always on our top priority, from design, planning, and construction to distribution and after-sales service we cater all the services to match client’s requirement.",
  },
  {
    id:1,
    image:project2,
    name: "TRANSPARENCY AND CONSISTENCY",
    info: "Customer is always on our top priority, from design, planning, and construction to distribution and after-sales service we cater all the services to match client’s requirement.",
  },
  {
    id:2,
    image:project3,
    name: "PROBLEM-SOLVING ABILITIES",
    info: "Customer is always on our top priority, from design, planning, and construction to distribution and after-sales service we cater all the services to match client’s requirement.",
  },
  {
    id:3,
    image:project4,
    name: "UNPARALLELED CONSTRUCTION QUALITY",
    info: "Customer is always on our top priority, from design, planning, and construction to distribution and after-sales service we cater all the services to match client’s requirement.",
  },
];

const whychoose = () => {
  return (
    <section id="image-background">
      <div className="side-padding">
        <div className="whychoose-project-card">
          <div className="whychoose-border">
            <h1>WHY CHOOSE US? </h1>
            <Container>
              <Row>
              {data1.map((user) => (
                <Col md={3} key={user.id} className="mobile-view-space">
                  <div className="whychoose-card">                   
                      <div >
                        <img src={user.image} width="100%" height="auto" alt="project" />
                        <h5>
                          <b>{user.name}</b>
                        </h5>
                        <p>{user.info}</p>
                      </div>
                  </div>
                </Col>))}
              </Row>
            </Container>
          </div>
        </div>
      </div>
    </section>
  );
};

export default whychoose;
