import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./Partners.css";
import React from "react";
import slider1 from "../../assets/Partners/slider1.jpg";
import slider2 from "../../assets/Partners/slider2.jpg";
import slider3 from "../../assets/Partners/slider3.jpg";
import slider4 from "../../assets/Partners/slider4.jpg";
import slider5 from "../../assets/Partners/slider5.jpg";
import slider6 from "../../assets/Partners/slider6.jpg";
import slider7 from "../../assets/Partners/slider7.jpg";
const data = [
  {
    id: 1,
    slider1: slider1,
  },
  {
    id: 2,
    slider1: slider2,
  },
  {
    id: 3,
    slider1: slider3,
  },
  {
    id: 4,
    slider1: slider4,
  },
  {
    id: 5,
    slider1: slider5,
  },
  {
    id: 6,
    slider1: slider6,
  },
  {
    id: 7,
    slider1: slider7,
  },
];

const Partners = () => {
  const settings = {
    infinite: true,
    dots: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    lazyLoad: true,
    autoplay: true,
    autoplaySpeed: 2000,
    speed:1000,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <section className="Partners-section">
      <h4 className="Partners-heading">
        OUR <strong>PATNERS</strong>
      </h4>
      <p className="Partners-info">We are associate with following partners</p>
      <div className="imgslider">
        <Slider {...settings}>
          {data.map((user) => (
            <div key={user.id}>
              <img
                className="Partners-logos-img"
                src={user.slider1}
                alt="slider"
              />
            </div>
          ))}
        </Slider>
      </div>
    </section>
  );
};
export default Partners;
