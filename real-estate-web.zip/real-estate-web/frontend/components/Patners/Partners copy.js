import React from "react";
import Carousel from "react-bootstrap/Carousel";
import slider1 from "../../assets/Partners/slider1.jpg";
import slider2 from "../../assets/Partners/slider2.jpg";
import slider3 from "../../assets/Partners/slider3.jpg";
import slider4 from "../../assets/Partners/slider4.jpg";
import slider5 from "../../assets/Partners/slider5.jpg";
import slider6 from "../../assets/Partners/slider6.jpg";
import slider7 from "../../assets/Partners/slider7.jpg";
import "./Partners.css";

const data = [
  {
    id: 1,
    slider1: slider1,
    slider2: slider7,
  },
  {
    id: 2,
    slider1: slider2,
    slider2: slider6,
  },
  {
    id: 3,
    slider1: slider3,
    slider2: slider5,
  },
  {
    id: 4,
    slider1: slider4,
    slider2: slider4,
  },
  {
    id: 5,
    slider1: slider5,
    slider2: slider3,
  },
  {
    id: 6,
    slider1: slider6,
    slider2: slider2,
  },
  // {
  //   id: 7,
  //   slider1: slider7,
  //   slider2: slider1,
  // },
];

const Partners = () => {
  return (
    <div>
      <h4 className="Partners-heading">
        OUR <strong>PATNERS</strong>
      </h4>
      <p className="Partners-info">We are associate with following partners</p>
      
        <Carousel data-bs-theme="dark">
        <Carousel.Item className="Partners-logos ">
          <div className="Partners-logo-slide">
          {data.map((user) => (
            <div key={user.id}>
              <img
                className="Partners-logos-img"
                src={user.slider1}
                alt="slider"
              />
            </div>
          ))}</div>
        </Carousel.Item>
        <Carousel.Item className="Partners-logos ">
          <div className="Partners-logo-slide">
          {data.map((user) => (
            <div key={user.id}>
              <img
                className="Partners-logos-img"
                src={user.slider2}
                alt="slider"
              />
            </div>
          ))}</div>
        </Carousel.Item>
        </Carousel>
       
        {/* <Carousel data-bs-theme="dark">
          <Carousel.Item className="Partners-logos">
          <img
                // className="Partners-logos-img"
                src={slider1}
                alt="slider"
              />
          </Carousel.Item>
          <Carousel.Item>
            <h3>Second slide label</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </Carousel.Item>
          <Carousel.Item>
            <h3>Third slide label</h3>
            <p>
              Praesent commodo cursus magna, vel scelerisque nisl consectetur.
            </p>
          </Carousel.Item>
        </Carousel> */}
    </div>
  );
};

export default Partners;
