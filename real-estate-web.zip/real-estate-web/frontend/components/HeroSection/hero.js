import Carousel from "react-bootstrap/Carousel";
import banner1 from "../../assets/slider/banner1.jpg";
import banner2 from "../../assets/slider/banner2.jpg";
import banner3 from "../../assets/slider/banner3.jpg";
import banner4 from "../../assets/slider/banner4.jpg";
import * as React from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import SearchIcon from "@mui/icons-material/Search";
import "./hero.css";
import { Container, Row } from "react-bootstrap";
import Col from "react-bootstrap/Col";

const projectType = [
  { label: "Project type" },
  { label: "Residential", link: "/residential" },
  { label: "Commercial", link: "/commercial" },
];

const projectStatus = [
  { label: "Project Status" },
  { label: "New Project", link: "/new-project" },
  { label: "Under Construction", link: "/under-construction" },
  { label: "Ready to move", link: "/ready-to-move" },
];

// const BuilderDeveloper = [
//   { label: "Builder/Developer" },
//   { label: "By Peridot", link: "/by-peridot" },
//   { label: "By Bharat Realty", link: "/by-bharat-realty" },
//   { label: "By Transcon Realty", link: "/by-transcon-realty" },
//   { label: "By Adani Realty", link: "/by-adani-realty" },
// ];

const configuration = [
  { label: "1BHK", link: "/1bhk" },
  { label: "2BHK", link: "/2bhk" },
  { label: "3BHK", link: "/3bhk" },
];

const location = [{ label: "location", link: "/location" }];

const propertyType = [
  { label: "Property type" },
  { label: "Residential", link: "/residential" },
  { label: "Commercial", link: "/commercial" },
];

const propertyStatus = [
  { label: "Property Status" },
  { label: "For sale", link: "/forsale" },
  { label: "For rent", link: "/forrent" },
];

const configurationProperty = [{ label: "Configuration" }];

const locationProperty = [{ label: "location", link: "/location" }];


function hero() {
  return (
    <div>
      <div className="hero-slider">
        <Carousel>
          <Carousel.Item interval={1000}>
            <img src={banner1} width="100%" height="auto" alt="banner1" />
          </Carousel.Item>
          <Carousel.Item interval={500}>
            <img src={banner2} width="100%" height="auto" alt="banner2" />
          </Carousel.Item>
          <Carousel.Item>
            <img src={banner3} width="100%" height="auto" alt="banner3" />
          </Carousel.Item>
          <Carousel.Item>
            <img src={banner4} width="100%" height="auto" alt="banner4" />
          </Carousel.Item>
        </Carousel>
      </div>

      <Container>
        <Row className="justify-content-md-center">
          <Col xs lg="11" className="hero-text">
            <b>Project Search</b>
            <Row className="hero-dropdown-text">
              <Col xs={2} className="hero-select-field">
                <Autocomplete
                  disablePortal
                  // id="combo-box-demo"
                  options={projectType}
                  // sx={{ width: 200 }}
                  renderInput={(params) => (
                    <TextField {...params} label="Project Type" />
                  )}
                />
              </Col>

              <Col xs={2} className="hero-select-field">
                <Autocomplete
                  disablePortal
                  options={projectStatus}
                  renderInput={(params) => (
                    <TextField {...params} label="Project Status" />
                  )}
                />
              </Col>
              {/* <Col xs={2} className="hero-select-field">
                <Autocomplete
                  disablePortal
                  options={BuilderDeveloper}
                  renderInput={(params) => (
                    <TextField {...params} label="By Peridot" />
                  )}
                />
              </Col> */}
              <Col xs={2} className="hero-select-field">
                <Autocomplete
                  disablePortal
                  options={configuration}
                  renderInput={(params) => (
                    <TextField {...params} label="Configuration" />
                  )}
                />
              </Col>
              <Col xs={2} className="hero-select-field">
                <Autocomplete
                  disablePortal
                  options={location}
                  renderInput={(params) => (
                    <TextField {...params} label="Location" />
                  )}
                />
              </Col>
              <Col xs={3} className="hero-select-field-button">
                <button
                  type="submit"
                  name="submit"
                  className="btn text-capitalize pull-right "
                  id="hero-submit-button"
                >
                  Search Project&nbsp;&nbsp;
                  <SearchIcon />
                </button>
              </Col>
            </Row>

            <b>Property Search</b>

            <Row className="hero-dropdown-text">
              <Col xs={2} className="hero-select-field">
                <Autocomplete
                  disablePortal
                  options={propertyType}
                  renderInput={(params) => (
                    <TextField {...params} label="Property Type" />
                  )}
                />
              </Col>
              <Col xs={2} className="hero-select-field">
                <Autocomplete
                  disablePortal
                  options={propertyStatus}
                  renderInput={(params) => (
                    <TextField {...params} label="Property Status" />
                  )}
                />
              </Col>
              <Col xs={2} className="hero-select-field">
                <Autocomplete
                  disablePortal
                  options={configurationProperty}
                  renderInput={(params) => (
                    <TextField {...params} label="Configuration" />
                  )}
                />
              </Col>
              <Col xs={2} className="hero-select-field">
                <Autocomplete
                  disablePortal
                  options={locationProperty}
                  renderInput={(params) => (
                    <TextField {...params} label="Location" />
                  )}
                />
              </Col>
              <Col xs={3} className="hero-select-field-button">
                <button
                  type="submit"
                  name="submit"
                  className="btn text-capitalize pull-right"
                  id="hero-submit-button"
                >
                  Search Property&nbsp;&nbsp;
                  <SearchIcon />
                </button>
              </Col>
            </Row>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default hero;


