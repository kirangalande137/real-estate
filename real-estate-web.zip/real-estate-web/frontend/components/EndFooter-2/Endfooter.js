import React from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import FacebookIcon from "@mui/icons-material/Facebook";
import TwitterIcon from "@mui/icons-material/Twitter";
import InstagramIcon from "@mui/icons-material/Instagram";
import YouTubeIcon from "@mui/icons-material/YouTube";
import "./Endfooter.css";
const Endfooter = () => {
  return (
    <div className="Endfooter">
      {" "}
      <Container>
        <Row>
          <Col xs={12} md={6}>
            <div className="Endfooter-left">
              <p>2021 © Copyright - All Rights Reserved.</p>
            </div>
          </Col>
          <Col xs={12} md={6}>
            <div className="Endfooter-right">
              <div>
                <a href="#" id="Endfooter-fb">
                  <FacebookIcon fontSize="small" />
                </a>
              </div>
              <div>
                <a href="#" id="Endfooter-twit">
                  <TwitterIcon fontSize="small" />
                </a>
              </div>
              <div>
                <a href="#" id="Endfooter-insta">
                  <InstagramIcon fontSize="small" />
                </a>
              </div>
              <div>
                <a href="#" id="Endfooter-yt">
                  <YouTubeIcon fontSize="small" />
                </a>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Endfooter;
