import { Route, Routes } from "react-router-dom";
import HomePage from "./pages/HomePage/HomePage";
import ProjectInnerPages from "./pages/ProjectInnerPages/ProjectInnerPages";
import LoginPage from "./pages/LoginPage/LoginPage";
import Services from "./components/Services/Services";
import Aboutus from "./components/Aboutus/Aboutus";
import ProjectDetailsPage from "./pages/ProjectDetailsPage/ProjectDetailsPage";
import AddFormProject from "./pages/AddForm/AddFormProject";
import { QueryClient, QueryClientProvider } from "react-query";

export const queryClient = new QueryClient();

const App = () => {
  return (
 
      <QueryClientProvider client={queryClient}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/blogdetails" element={<ProjectInnerPages />} />
          <Route path="/loginpage" element={<LoginPage />} />
          <Route path="/about" element={<Aboutus />} />
          <Route path="/services" element={<Services />} />
          <Route path="/projectdetails" element={<ProjectDetailsPage />} />
          <Route path="/addproject" element={<AddFormProject />} />
        </Routes>
      </QueryClientProvider>
  );
  
};
export default App;

