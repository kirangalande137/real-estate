import React from "react";
import TopHeader from "../../components/Topheader/Topheader";
import Header from "../../components/Header/Header";
import BlogDetails from "../../components/BlogDetails/BlogDetails";
import Footer from "../../components/Footer/footer";
import EndFooter from "../../components/EndFooter/endfooter";
// import Aboutus from "../../components/Aboutus/Aboutus";
const ProjectInnerPages = () => {
  return (
    <>
      <TopHeader />
      <Header />
      <BlogDetails />
      {/* <Aboutus /> */}
      <Footer />
      <EndFooter />
    </>
  );
};

export default ProjectInnerPages;
