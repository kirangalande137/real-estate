import React from "react";
import ProjectDetails from "../../components/ProjectDetails/ProjectDetails";

const ProjectDetailsPage = () => {
  return (
    <>
      <ProjectDetails />
    </>
  );
};

export default ProjectDetailsPage;
