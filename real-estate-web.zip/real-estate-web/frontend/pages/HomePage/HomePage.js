import React from "react";
import TopHeader from "../../components/Topheader/Topheader";
import Header from "../../components/Header/Header";
// import HeroSection from "../../components/HeroSection/hero";
import HeroSection2 from "../../components/HeroSection2/hero2";
// import ProjectsSection from "../../components/Projects/Project";
import Blog from "../../components/Blog/Blog";
import OnlineProject from "../../components/OnlineProject/OnlineProject";
import Whychoose from "../../components/whychoose/whychoose";
import ClientTestimonials from "../../components/ClientTestimonials/ClientTestimonials";
import Partners from "../../components/Patners/Partners";
import ContactUs from "../../components/ContactUs/ContactUs";
import Footer from "../../components/Footer/footer";
import Footer2 from "../../components/Footer-2/Footer";
import EndFooter from "../../components/EndFooter/endfooter";
import EndFooter2 from "../../components/EndFooter-2/Endfooter";
import FloatingButtons from "../../components/FloatingButtons/FloatingButtons";

const HomePage = () => {
  return (
    <>
      <TopHeader />
      <Header />
      {/* <HeroSection /> */}
      <HeroSection2 />
      {/* <ProjectsSection /> */}
      <Blog />
      <OnlineProject />
      <Whychoose />
      <ClientTestimonials />
      <Partners />
      <ContactUs />
      <Footer />
      <Footer2 />
      <EndFooter2 />
      <EndFooter />
      <FloatingButtons 
         name="ENQURIE BUTTON"
         buttontype1="enqurie"
         buttontype2="whatsapp"
       />
    </>
  );
};

export default HomePage;
