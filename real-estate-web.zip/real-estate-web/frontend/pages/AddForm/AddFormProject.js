import React from 'react'
import AddForm from '../../components/AddForm/AddForm'
const AddFormProject = () => {
  return (
    <>
      <AddForm />
    </>
  )
}

export default AddFormProject