import React from "react";
import TopHeader from "../../components/Topheader/Topheader";
import Header from "../../components/Header/Header";
import Login from "../../components/Login/Login"
import Footer from "../../components/Footer/footer";
import EndFooter from "../../components/EndFooter/endfooter";
const LoginPage = () => {
  return (
    <>
      {/* <TopHeader />
      <Header /> */}
      <Login />
      {/* <Footer />
      <EndFooter /> */}
    </>
  );
};

export default LoginPage;