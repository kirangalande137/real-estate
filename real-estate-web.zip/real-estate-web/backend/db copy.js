const express = require("express");
const mysql = require("mysql");
const cors = require("cors");
const multer = require("multer");

const app = express();
app.use(cors());
app.use(express.json());

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Specify the folder where images will be stored
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname); // Generate a unique filename
  },
});

const upload = multer({ storage: storage });

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "signin",
});

app.post("/loginpage", (req, res) => {
  const sql = "SELECT * FROM admin WHERE email = ? AND password = ?";
  db.query(sql, [req.body.email, req.body.password], (err, result) => {
    if (err) {
      res.status(500).json({ error: "Internal server error" });
    } else {
      if (result.length > 0) {
        console.log(result);
        res.send("Login successful");
      } else {
        res.send("Wrong Username And Password");
      }
    }
  });
});
app.post("/AddProject", upload.single('projectImage'), (req, res) => {
   // Convert amenities array to string
   const amenitiesString = req.body.amenities.join(", ");
   const projectImage = req.file.featuredimage; 
   console.log(req.file.featuredimage);
  console.log(req.body);
  const sql =
    "INSERT INTO project_type (ptitle,subtitle,ptype,pcategory,pstatus,buildername,availablefrom,rerano,pprice,parking,description,videolink,pstate,pcity,plocation,paddress,disclaimer,comments,featured,visibility) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
  db.query(
    sql,
    [
      req.body.projectName,
      req.body.subTittle,
      req.body.projectType,
      req.body.projectCategory,
      req.body.projectStatus,
      req.body.builderName,
      req.body.availableForm,
      req.body.reraNum,
      req.body.projectprice,
      req.body.parking,
      req.body.description,
      req.body.videolink,
      req.body.selectstate,
      req.body.selectcity,
      projectImage,
      req.body.location,
      req.body.address,
      amenitiesString,
      req.body.disclaimber,
      req.body.comments,
      req.body.selectFeatured,
      req.body.selectVisibilty,
    ],
    (err, result) => {
      if (err) {
        console.log(err);
        res.status(500).json({ error: "Internal server error" });
      } else {
        if (result) {
          res.send("Login successful");
          // console.log("Login successful");
        }
      }
    }
  );
});

app.listen(3001, () => {
  console.log("connect to the server");
});
